package in.neha;

public class InbuildMethodException {

	public static void main(String[] args) {
		
		int a = 1, b = -1; 

		try {
			
			if(a<0 || b<0) {
				
				throw new ArithmeticException( " Either one value is negative ");
		}
			
			else {
				
				System.out.println(" Positive value ");
			}
			
	}
			
	    catch(ArithmeticException e) {
	    	
	    	  e.printStackTrace();
	     }
		
	}

 }
