

package in.neha;

import java.util.Scanner;

class ValidateData { 
	
	   String username , password;
	   
	  void inputData() {
		  
		   Scanner sc = new Scanner(System.in);
		   
		  try {
			  
		  System.out.println(" Enter the Usename ");
		  username = sc.next();
		  
		  System.out.println(" Enter the Password ");
		  password = sc.next();
		  
	    }
		  
		  catch(NumberFormatException | NullPointerException e) {
			  
			  e.printStackTrace();
			  
		 }
		  
	 }
	  
	  void checkData() {
		  
		  if(username.equalsIgnoreCase("Admin") && password.equalsIgnoreCase("Admin123")) {
		  
		      System.out.println(" Validate User Input... ");
		  
	     }
	  
	     else {
	    	 
	    	 System.out.println(" Invalid Input ");
	    	    	 
	     }  
		  
     }   
	  
  }

public class UserValidation {

	public static void main(String[] args) {
		
		ValidateData ob = new ValidateData();
		
		ob.inputData();
		
		ob.checkData();
		
	  }

    }

  
