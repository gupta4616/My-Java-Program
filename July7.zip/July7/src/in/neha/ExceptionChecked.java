

package in.neha;

import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;

public class ExceptionChecked {

	public static void main(String[] args) {
		
	    InputStreamReader in = new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(in);
		
		    String name;
		    
		    int age;
		    
		    float fees;
		    
		    
		   try {
			   
			   System.out.println(" Enter Name ");
			   name = br.readLine();
			   
			   System.out.println(" Enter Age ");
			   age = Integer.parseInt(br.readLine()) ;
			   
			   System.out.println(" Enter Fess ");
			   fees = Float.parseFloat(br.readLine());
			   
			   
			   System.out.println(" Name = " +name);
			   
			   System.out.println(" Age = " +age);
			   
			   System.out.println(" Fees = " +fees);
			   
			   
		   }
		   
		   catch(IOException e) {
			   
			   e.printStackTrace();
		   
		   }
		   
	  }

   }
