

package in.neha;

class AgeException extends Exception {
	
	 public AgeException(String s) {
		 
		 super(s);
		 
	 }
	 
  }

class voteAge {
	
	 public void AgeException(int age) {
		 
		 if(age<18) {
			 
			 try {
				 
				 AgeException ob = new AgeException(" Not Eligible for Voting");
				 
				 throw ob;
				 
			 }
			 
			 catch( AgeException e) {
				 
				 e.printStackTrace();
				 
				 System.out.println(e);
				 
			 }
			 
		 }
			 
			else {
				
				System.out.println(" Eligible for Voting ");
				
		}
		 
     }
	 
  } 


public class CustomExceptionAge {

	public static void main(String[] args) {
		
		voteAge obj = new voteAge();
		
		obj.AgeException(16);

	 }

  }
