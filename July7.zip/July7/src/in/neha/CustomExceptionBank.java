

package in.neha;

class BankException extends Exception {
	
	  public BankException(String s) {
		  
		  super(s);
		  
	  }
	  
   }
	  
class Bank {
	
	  void checkBankBalance(int Amount) {
		  
		  if(Amount < 10000) {
			  
			  try {
				  
	  BankException obj = new  BankException(" Insufficient Balance ");
	      
	      throw obj;
	  
			  }
			  
			  catch(BankException e) {
				  
				  e.printStackTrace();
				  
				  System.out.println(e);
				  
			   }
			  
		}
			  
		 else {
			 
			 System.out.println(" You can Withdraw The Amount ");
			 
		 }
			  
	  }
	  
   }

public class CustomExceptionBank {

	public static void main(String[] args) {
     
		 Bank ob = new  Bank();
		 
		 ob.checkBankBalance(120);
			
	}

  }



	


	
