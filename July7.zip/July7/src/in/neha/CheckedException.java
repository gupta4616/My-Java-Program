

package in.neha;

import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;


public class CheckedException {

	public static void main(String[] args) {
		
 //BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
		
	    InputStreamReader in = new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(in);
		
		  System.out.println(" Enter Name ");
		  
		  
		     try {
		    	 
		    	 String name = br.readLine();
		    	 
		     }
		     
		     catch(IOException e) {
		    	 
		    	 e.printStackTrace();
		    	  
		     }

	     }

    }
