

package in.neha;

class OverloadClass {
	
	void display() {
		
		System.out.println(" No argument Function ");
		
	}
	
     void display(int i) {
		
		System.out.println(" one argument Function With Int ");
		
	}
     
     void display(float f) {
 		
    	 System.out.println(" one argument Function With Float ");
    	 
     }
     			
     void display(double d) {
 		
    	 System.out.println(" one argument Function With double ");
 		
 	}
     
     void display(long l) {
 		
    	 System.out.println(" one argument Function With long ");
 	}
     
     void display(char c) {
 		
    	 System.out.println(" one argument Function With char ");
 		
     }
     
     void display(String s) {
 		
 		System.out.println(" No argument Function With String ");
 		
 	}
     
     void display(short s) {
 		
    	 System.out.println(" one argument Function With short");
 	}
     
     void display(byte b) {
 		
    	 System.out.println(" one argument Function With Byte");
 		
 	}
     
     void display(int i, int j) {
 		
 		System.out.println(" Two argument Function With Same Datatype ");
 		
 	}
     
     void display(int i, float j) {
 		
 		System.out.println(" Two argument Function With Diffrent Datatype ");
 		
 	}
     
     void display(float i, int j) {
 		
 		System.out.println(" Two argument Function By Interchange Argument  ");
 		
 	}
     
  }

public class OverloadingMethods {

	public static void main(String[] args) {
		
		OverloadClass obj = new OverloadClass();
		
	    obj.display();
	    
	    obj.display(10);
	    
	    obj.display(77.87f);
	    
	    obj.display(88674d);
	    
	    obj.display(112222l);
	    
	    obj.display('R');
	    
	    obj.display("NNG");
	    
	    obj.display( (short) 43);
	    
	    obj.display( (byte) 88675 );
	    
	    obj.display(2, 50);
	    
	    obj.display(34, 54.7f);
	    
	    obj.display(645.1f, 23);

	}

}
