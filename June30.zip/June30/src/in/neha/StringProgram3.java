

package in.neha;

public class StringProgram3 {

	public static void main(String[] args) { 
		
		String str = "Computer Is Fun";
		
		StringBuilder sb = new StringBuilder(str);
		
		System.out.println(sb.reverse());
		
		
		
		
		
	}

	}


