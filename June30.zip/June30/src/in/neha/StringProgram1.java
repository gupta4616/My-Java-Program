

package in.neha;

public class StringProgram1 {

	public static void main(String[] args) {
		
			String s ="TATA STEEL IS IN JAMSHEDPUR";
			
			String str="";
			
			    for(int i=0;i<s.length();i++) { 
				
				char ch=s.charAt(i); 
				
				   if(ch=='A'||ch=='E'||ch=='I'|| ch=='O'||ch=='U') {
					
					str=str+"*";		
				}
				
				 else {
					
					 str=str+ch; 
				}
			}
			
			
			System.out.println(str);	

	}

}
