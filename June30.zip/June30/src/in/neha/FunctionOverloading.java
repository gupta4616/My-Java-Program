

package in.neha;

class Overload {
	
	    void addition(int i , int j) {
		   
		   System.out.println(" Sum of Integers " +(i+j) );
	   }
      
        void addition(float i , float j) {
		   
		   System.out.println(" Sum of float " +(i+j) );
	   }

        void addition(double i , double j) {
		   
		   System.out.println(" Sum of double " +(i+j) );
	   }
       

        void addition(short i , short j) {
		   
		   System.out.println(" Sum of short " +(i+j) );
	   }
        
        void addition(byte i,byte j) {
        	
        	System.out.println(" Sum of byte " +(i+j) );
        }
	
}

public class FunctionOverloading {

	public static void main(String[] args) {
		
       Overload ob = new Overload ();
		
		ob.addition(6, 7);
		
		ob.addition(6.3f, 3.4f);
		
		ob.addition(6.3, 3.4);
		
		ob.addition( (short)7, (short)8 );
		
		ob.addition( (byte)8, (byte)7 );
	


	}

}
