

package in.neha;

public class Addition {
	
	   int a,b,sum;   // instance variable
	  
	   Addition() {  //constructor
		   
		   a = 10;
		   
		   b = 20;
		   
		  //System.out.println(" Constructor is called ");
		  
		  //System.out.println(" Constructor is used to intialize the member data of the class ");
		   
	   }
	   
        void add() {
		   
		   sum = a+b;
		   
		   System.out.println(" Sum = " +sum);
		   
	   }
	  	   
	   Addition(int i, int j) {
		   
		   a = i;
		   
		   b = j;
		   
	   }
	   
	   
  public static void main(String[] args) {
		
		Addition ob = new Addition();
		
		ob.add();
		
		Addition obj = new Addition(4, 7);
		
		obj.add();
		
	  }

  }
