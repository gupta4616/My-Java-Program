

package in.neha;

import java.util.Iterator;
import java.util.TreeSet;

public class EmployeeMain {

	public static void main(String[] args) {
		
		 Employee e1 = new Employee(123, "Neha", 5672f);
		 
		 Employee e2 = new Employee(125, "Divya", 5676f);
		 
		 Employee e3 = new Employee(1673, "Gopal", 9668f);
		 
		 Employee e4 = new Employee(1673, "Kiran", 9542f);
		 
		 Employee e5 = new Employee(345, "Suresh", 5622f);
		 
		 
		 //sorting by id
		 TreeSet<Employee> tst = new TreeSet<Employee>(new SortById() );
		 tst.add(e1);
		 
		 tst.add(e2);
		 
		 tst.add(e3);
		 
		 tst.add(e4);
		 
		 tst.add(e5);
		 
		 
		 System.out.println(" Sorting based on id ");
		 
		  Iterator<Employee> it = tst.iterator();
		 
		      while(it.hasNext()) {
		    	
		    	Employee e = it.next();
		    	
		    	System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
		    	
		    }
		    	
		     //sorting by salary
			 TreeSet<Employee> tst1 = new TreeSet<Employee>(new SortBySalary() );
			 
			 tst1.add(e1);
			 
			 tst1.add(e2);
			 
			 tst1.add(e3);
			 
			 tst1.add(e4);
			 
			 tst1.add(e5);
			 
			 
			 System.out.println(" Sorting based on salary ");
			 
			 Iterator<Employee> it1 = tst1.iterator();
			 
			     while(it1.hasNext()) {
			    	
			    	Employee e = it1.next();
			    	
			    	System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
		  }
			    	
			   // sorting by name
			   TreeSet<Employee> tst2 = new TreeSet<Employee>(new SortByName() );
				tst2.add(e1);
				
				tst2.add(e2);
				
				tst2.add(e3);
				
				tst2.add(e4);
				
				tst2.add(e5);
				 
				 System.out.println(" Sorting based on Name");
				 
				  Iterator<Employee> it2 = tst2.iterator();
				 
				     while(it2.hasNext()) {
				    	
				        Employee e = it2.next();
				    	
				    	System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
				    	
          }
				     
	  }

   }
