

package in.neha1;

import java.util.LinkedHashMap;

import java.util.Map;

public class LinkedHashMapMain {

	public static void main(String[] args) {
		
       LinkedHashMap<String, String> ob = new LinkedHashMap<String, String>();
		
		ob.put("6786371217", "Neha");
		
		ob.put("2123121496" , "Anu");

		ob.put("6988971453", "Priti");

		ob.put("6786343208", "Ravi");
		
		System.out.println(ob);
		
		
		 // Travesing 
          for(Map.Entry<String, String> eob:ob.entrySet()) {
			
		       System.out.println(eob.getKey()+"\t"+eob.getValue());
	
	 }

   }
	
 }
