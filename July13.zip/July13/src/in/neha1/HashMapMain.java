

package in.neha1;

import java.util.HashMap;

import java.util.Map;

public class HashMapMain {

	public static void main(String[] args) {
		
        HashMap<String, String> ob = new HashMap<String, String>();
		
		ob.put("6786371217", "Neha");
		
		ob.put("2123121496" , "Anu");

		ob.put("6988971453", "Priti");

		ob.put("6786343208", "Ravi");
		
		System.out.println(ob);
		
		
		 // travesing like itrator only in map
         for(Map.Entry<String, String> eob:ob.entrySet()) {
			
			  System.out.println(eob.getKey()+"\t"+eob.getValue());
			
	  }

    }
	
  }
