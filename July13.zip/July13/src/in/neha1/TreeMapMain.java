

package in.neha1;

import java.util.Map;

import java.util.TreeMap;

public class TreeMapMain {

	public static void main(String[] args) {
		
		TreeMap<String, String> ob = new TreeMap<String, String>();
		
		ob.put("6786371217", "Neha");
		
		ob.put("2123121496" , "Anu");

		ob.put("6988971453", "Priti");

		ob.put("6786343208", "Ravi");
		
		System.out.println(ob);
		
		
		//Traversing
		for(Map.Entry<String, String> eob:ob.entrySet()) {
			
			  System.out.println(eob.getKey()+"\t"+eob.getValue());
			
		}
		
	 }

  }
