// average of number using array 

package in.neha;

import java.util.Scanner;

public class AvarageOfArray {

public static void main(String[] args) {
	
	int ar[],size,sum=0;
	 
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the size of an array");
	size = sc.nextInt();
	ar = new int[size];
	
	System.out.println("Enter "+size+" of elements");
	
	for(int i=0;i<size;i++) {
		ar[i] = sc.nextInt();
	}
	
	//System.out.println("Entered elements are");
	
	//for(int i=0;i<size;i++) {
		//System.out.println(ar[i]);
	//}

	 for(int i=0;i<size;i++) {
		sum=sum+ar[i];
	}
	 
	System.out.println("Sum of all array elements ="+sum);
	
	  int Avg = sum /size;
	
	System.out.println(" avrage of number = " +Avg);
	  
  }

	}


