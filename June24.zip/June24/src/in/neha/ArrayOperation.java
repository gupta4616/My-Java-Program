// using class and object 

package in.neha;

import java.util.Scanner;

class ArrayOp {
	
	  int ar[], size=0;
	  
	  int sum=0;
	  
     void inputData() {
			
		 Scanner sc = new Scanner(System.in);
			
		 System.out.println(" Enter the size of an array ");
			
			size = sc.nextInt();
			ar = new int[size];
			
		  System.out.println(" Enter "+size+" of elements ");
			
			for(int i=0;i<size;i++) {
				
				ar[i] = sc.nextInt();
				
		}
		
     }
			 
	   void calculationSum() {
		   
		  // int sum=0;
		   
		     for(int i=0;i<size;i++) {
			   
				sum =sum +ar [i];
		 }
		   
			System.out.println(" Sum of all array elements = " +sum );
			
	     }
	   
	   void calculationAvg() {
		   
		     int Avg = sum /size;
			
			System.out.println(" Avrage of array elments =  " +Avg);
			  
		   }
	   
	   void calculateLargest() {
		   
		  int max=ar[0];
		      
			  for(int i=1;i<size;i++) {
				  
				 if(ar[i]>max) {
					 
					max = ar[i];
				}
				 
			}
			
			System.out.println(" Largest element of an array is = " +max );
			
	    }
	   
	    void calculateLeast() {
	    	
	      int min=ar[0];
			
			for(int i=1;i<size;i++) {
				
				if(ar[i]<min) {
					
					min = ar[i];
		  }

	   }
			System.out.println(" Least element of an array is = "  +min );
			 
	   }   
	    
			 	 
	     }

			
public class ArrayOperation {

public static void main(String[] args) { 
	
	 ArrayOp obj = new ArrayOp();
	 
	  obj.inputData();
	  
	  obj.calculationSum();
	  
	  obj.calculationAvg();
	  
	  obj.calculateLargest();
	  
	  obj.calculateLeast();
	  

    }

  }
