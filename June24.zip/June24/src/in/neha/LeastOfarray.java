// find least number usimg array 

package in.neha;

import java.util.Scanner;

public class LeastOfarray {

public static void main(String[] args) {
		
     int ar[],size;
	
	 Scanner sc = new Scanner(System.in);
	
	 System.out.println("Enter the size of an array");
	
	 size = sc.nextInt();
	 ar = new int[size];
	
	 System.out.println("Enter "+size+" of elements");
	
	   for(int i=0;i<size;i++) {
		ar[i] = sc.nextInt();
	}
	
	   //least elements of array 
		int min=ar[0];
		
		for(int i=1;i<size;i++) {
			
			if(ar[i]<min) {
				
				min = ar[i];
	}

}
		 System.out.println(" Least element of an array is " +min);
		 
   }

 }
