// array demo 

package in.neha;

public class ArrayDemo {

public static void main(String[] args) {
	
	 int ar[] = {3,7,8,9};
	 
	  for(int i=0; i<ar.length; i++) {
		  System.out.print(  ar [ i ] );
	  }
       
	 //for(int i=ar.length-1; i>=0; i--) {
		 // System.out.println(ar[i]);
	//}
	
	 //for(int i:ar) {
		 // System.out.println(i);
	 // }
	}
}


