// find largest number using the array

package in.neha;

import java.util.Scanner;

public class LargestOfArray {

public static void main(String[] args) {
		
	int ar[],size;
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the size of an array");
	
	size = sc.nextInt();
	ar = new int[size];
	
	System.out.println("Enter "+size+" of elements");
	
	for(int i=0;i<size;i++) {
		ar[i] = sc.nextInt();
	}
	
	//largest of array elements
	
	  int max=ar[0];
	  
	  for(int i=1;i<size;i++) {
		  
		 if(ar[i]>max) {
			 
			max = ar[i];
		}
	}
	
	System.out.println("Largest element of an array is "+max);
	

	}

}
