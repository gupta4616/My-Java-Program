

package in.neha;

import java.util.Scanner;

class Showroom {
	
	 String name;
	 
	 long Mobno;
	 
	 double cost;
	 
	 double amount;
	 
	 double discount;
	 
	 
	 Showroom() {
		 
		 name = null;
		 
		 Mobno = 0;
		 
		 cost = 0.0;
		 
		 amount = 0.0;
		 
		 discount = 0.0;
		 
	 } 
		 void input() {
			 
			 Scanner sc = new Scanner(System.in);
			 
			 System.out.println(" Enter Name : " );
			 name = sc.nextLine();
			 
			 System.out.println(" Enter the Mobile Numbwe : ");
			 Mobno = sc.nextLong();
			 
			 System.out.println(" Enter the Cost : ");
			 cost = sc.nextDouble();
			 
		 }
		 
		  void calculate() {
			  
			  if(cost>=10000) {
				   discount = cost*5 /100;
				    
			  }
			  
			  else if (cost<10000 && cost>=20000) {
				   discount = cost*10 /100;
				   
			  }
			  
			  else if (cost>20000 && cost<=350000) {
				   discount = cost*15 /100;
				   
			  }
			  
			  else if (cost<35000) {
				   discount = cost*20 /100;
				   
			  }
						
		}
		  
		  void display() {
			  
			  System.out.println( " Customers Name - " + name );
			  
			  System.out.println( " Mobile Number - " + Mobno );
			  
			  System.out.println( " Total Amount - " +(cost-discount )+ " Rs " );
			  
		  }		 
			 
	   }
		 

public class ShowrooomMain {

	public static void main(String[] args) {
		
		Showroom  obj = new Showroom ();
		
		obj.input();
		
		obj.calculate();
		
		obj.display();

	}

}
