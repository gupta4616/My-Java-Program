

package in.neha;

class Area {
	
	 // calculate area of rectangle 
	
	     void area (int l, int b) {
	    	 
	    	 int area = l*b;
	    	 
	    	 System.out.println(" Area of Rectangle = " +area );
	    	 
	     }
	     
	   // calculate area of square
	     
	     void area (int side) {
	    	 
	    	 int area = side*side;
	    	 
	    	 System.out.println(" Area of Square = " +area );
	    	 
	     }
	     
	     // calculate area of triangle 
	     
	       void area (float b, float h) {
	    	   
	    	   float area = (b*h) /2f;
	    	   
	    	   System.out.println(" Area of Triangle = " +area );
	    	   
	       }
	       
	       // calculate area of circle 
	       
	        void area (float r) {
	        	
	        	float area = (3.14f)*r*r;
	        	
	        	System.out.println(" Area of circle = " +area );
	        	
	       }	
     }


public class AreaOfFigure {

	public static void main(String[] args) {
		
		Area obj = new Area();
		
		obj.area(2, 3);
		
		obj.area(4);
		
		obj.area(5f, 6f);
		
		obj.area(7f);
		
	}

 }
