

package in.neha;

import java.util.Scanner;

class Parking {
	 
	   int Vno;
	   
	   int hours; 
	   
	   double bill;
	   
	   
	   void input () {
		   
		   Scanner sc = new Scanner(System.in);
		   
		   System.out.println(" Enter the Vehicle Number - " );
		   Vno = sc.nextInt();
		   
		   System.out.println(" Enter the Hours - " );
		   hours = sc.nextInt();
		   
	   }
	   
	   void calculate () {
		   
		   double  Normalcharges =3;
		   
		   if(hours<=1) {
			   
			    bill = Normalcharges ;
			   
		   }
		   
		   else if (hours>=1)
			  
			   bill = Normalcharges*hours + 1.50*hours ;
			   
		   }
	   
	     void display () {
	    	 
	    	 System.out.println(" Enter the Vehicle Number -" +Vno);
	    	 
	    	 System.out.println(" Parking Hours -" +hours + " hr ");
	    	 
	    	 System.out.println(" Total Bill Amount -" +bill +" Rs ");
	    	 
	   }
	
}


public class ParkingLot {

	public static void main(String[] args) {
		
		Parking obj = new Parking();
		
		obj.input();
		
		obj.calculate();
		
		obj.display();
		

	}

}
