

package in.neha;

class MySeries {
	
	 void series(int x, int n) {
		 
		 double sum=0;
		 
		   for(int i=1; i<=n; i++) {
			   
			   sum = sum+Math.pow(x, i);
			   
		  }
		   
		   System.out.println(" Sum of X1 +X2 +X3 + ........... Xn = " +sum);
		 
	 }
	 
	 void series(int p ) {
		 
		    for(int i =1; i<p; i++) {
		    	
		    	System.out.print( ( i*i*i )-1 +" , ");
		    	
		    	
		  }
		    
		    System.out.println( );
		    
	  }
	  
	 
	 void series() {
	
		  double sum=0;
		  
		    for(int i=2; i<=10; i++) {
		    	
		    	sum = sum+( (double) 1/i );
		    	
		    }
		    
		    System.out.println(" Sum of 1/2 + 1/3 + 1/4 +.......1/10 = " +sum);
	
	  }
	
  }


public class SeriesMain {

	public static void main(String[] args) {
		
		MySeries obj = new MySeries();
		
		obj.series(6, 7);
		
		obj.series(8);
		
		obj.series();
		

	}

}
