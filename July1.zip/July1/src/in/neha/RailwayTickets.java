

package in.neha;

import java.util.Scanner;

class Tickets{
	
	String name;
	
	String coach;
	
	long mobno;
	
	int amt;
	
	int totalamt;
	
	
	  void accept() {
		 
		 Scanner sc = new Scanner(System.in);
		 
		 System.out.println( " Enter Your Name - " );
		 name = sc.next();
		 
		 System.out.println( " Choose Your Coach - " );
		 coach = sc.next();
		 
		 System.out.println( " Enter Mobile Number - " );
		 mobno = sc.nextLong();
		 
		 System.out.println( " Enter the Amount - " );
		 amt = sc.nextInt();
	 }

	 
	   void update () {
		   
		   if (coach == "First_Ac") {
			   
			  totalamt = amt+700;		   
		   }
		   
		   else if (coach.equals("second_Ac") ) {
			   
			   totalamt = amt+500;   
		   }
		   
		   else if (coach.equalsIgnoreCase("Third_Ac") ) {
			   
			   totalamt = amt+250;
		   }
		   
		   else if (coach.equalsIgnoreCase("Sleeper") ) {
			   
			   totalamt = amt;
		   }
		   
		   else {
			   
			   System.out.println(" Invalid ");
			   
		   }
	   }
	   
	   void display () {
		   
		   System.out.println( " Name - " +name );
		   
		   System.out.println( " Coach - " +coach );
		   
		   System.out.println( " Mobile No. - " +mobno );
		   
		   System.out.println( " Your Total Amount - " +totalamt);   
		   
	   }
	   
  }

public class RailwayTickets {

	public static void main(String[] args) {
		
		Tickets obj = new Tickets();
		
		obj.accept();
		
		obj.update();
		
		obj.display();
		

	}

}
