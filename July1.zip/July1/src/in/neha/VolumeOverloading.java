

package in.neha;

class volume {
	  //double vol =0;
	  
	 double volume (double r) {
		 
		 double vol = (4*3)*(22/7)*(r*r*r);
		 
		 return vol;
		 
	 }
	 
	 double volume (double h, double r) {
		 
		 double vol = (22/7)*(r*r)*h;
		 
		 return vol = (22/7)*(r*r)*h;
	 }
	 
	  double volume (double l, double b, double h) {
		 
		 //vol = l*b*h;
		 
		 return l*b*h;
	 }
}

public class VolumeOverloading {

	public static void main(String[] args) {
		
		volume obj = new volume ();
		
		System.out.println(" Volume of a Sphere is = " + obj.volume ( 4 ) );
		
	    System.out.println(" Volume of a Cylinder is = " + obj.volume ( 5, 6 ) );
	    
	    System.out.println (" Volume of a Cuboid is = " + obj.volume ( 7, 8, 9 ) );
	

	}
	
   }
