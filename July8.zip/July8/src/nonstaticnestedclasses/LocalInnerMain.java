// local inner class is written in method of outer class

package nonstaticnestedclasses;

class LocalOuterClass {
	
	  void localOuterMethod() {
		  
		  System.out.println(" Local Outer Method ");
		  
		  
		  class LocalInnerClass {
			  
			  void localInnerMethod() {
				  
				  System.out.println(" Local Inner Method ");
				  
			 }
			  
		  }
		  
		  LocalInnerClass ob = new LocalInnerClass();
		  
		  ob.localInnerMethod();
		  
	  }
	  
   }

public class LocalInnerMain {

	public static void main(String[] args) {
		
		LocalOuterClass obj = new LocalOuterClass();
		
		obj.localOuterMethod();

	  }

   }
