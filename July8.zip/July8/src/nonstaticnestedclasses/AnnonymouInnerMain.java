// annonymous inner class only in use in when class is abstract or interface

package nonstaticnestedclasses;

abstract class AbstractClass {
	
	  abstract void display();
	  
   }


interface MyInterface {
	
	   void intMethod1();
	   
	   void intMethod2();
	   
  }


public class AnnonymouInnerMain {

	public static void main(String[] args) {
		
		AbstractClass aob = new AbstractClass() {
			
		//AbstractClass() {   }. // calling method          // this is also valid
			
		

			@Override
			void display() {
				
				System.out.println(" Abstract Class Display ");
				
	       }
			
	   };  // abstract class close with cemicolon
	   
	     //aob.display();
		
		
	     MyInterface iob = new MyInterface() {

			@Override
			public void intMethod1() {
				
				 System.out.println(" Interface Method 1 ");
				
			}

			@Override
			public void intMethod2() {
				
				System.out.println(" Interface Method 2 ");
					
			}
	    	 
	    };    // interface methods close with cemicolon
		
	     iob.intMethod1();
	     
	    // iob.intMethod2();

	   }

   }
