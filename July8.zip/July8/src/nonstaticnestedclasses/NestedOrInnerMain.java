// class inside another class is innerclass or nested class

package nonstaticnestedclasses;

class OuterClass {
	
      int i = 10 ,j = 10;
      
      //OuterClass() {    //constructor always not neccessary
    	  
    	  //i=10;
    	  
    	  //j=10;
    	  
    //  }
    	  
      class InnerClass {
    	  
    	  void innerMethod() {
    		  
    		  System.out.println(" Sum = " +(i+j));
    		  
    		  System.out.println(" Inner Method ");
    		  
    	  }
    	 	  
      }
      
          void outerMethod() {
        	  
        	  System.out.println(" Sum = " +(i+j));
        	  
        	  System.out.println(" Outer Method ");
        	  
        	  
       InnerClass ob = new InnerClass(); // create inner class object to calling that method
        	  
        	  ob.innerMethod();
        	  
           }
    	    	  
      }
	 

public class NestedOrInnerMain {

	public static void main(String[] args) {
		
		  OuterClass obj = new OuterClass();
		  
		  obj.outerMethod();

	    }

     }


