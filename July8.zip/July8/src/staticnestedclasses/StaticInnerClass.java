// static inner class can access only static data of outer class

package staticnestedclasses;

class ABC {
	
	 int i = 10;
	 
	 static int j = 100;
	
	   static class XYZ {
		   
		   void dispaly() {
			   
			   System.out.println(" The Number = " +j);
			   
		   }
		   
	   }
	   
   }

public class StaticInnerClass {

	public static void main(String[] args) {
		
		ABC.XYZ ax = new ABC.XYZ();
		
		ax.dispaly();

	  }

   }
