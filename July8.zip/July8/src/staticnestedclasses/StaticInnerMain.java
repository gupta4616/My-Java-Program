// in static keyword only inner class can be static

package staticnestedclasses;

class OuterClass {
	
	  static class innerStatic {
		  
		  void innerMethod() {
			  
			  System.out.println(" Static Inner Class Method ");
			  
		  }
		  
	   }
	
    }
	  

public class StaticInnerMain {

	public static void main(String[] args) {  
		
		OuterClass.innerStatic ob = new OuterClass.innerStatic();
		
		ob.innerMethod();
		
	  }

   }
