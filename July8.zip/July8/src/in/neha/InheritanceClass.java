

package in.neha;

class parent1 {
	
	int pid;
	
	String pname;

  }

class Child2 extends parent1 {
	
	int cid;
	
	String cname;
	
	
	Child2() { // constructor
		
	    pid = 10;
		
	    pname = "Parent";
		
		cid=20;
		
		cname = "child";
		
	}
	
	  void display() {
		  
		  System.out.println(" Parent Name = " +pname);
		  
		  System.out.println(" Parent ID = " +pid);
		 
		  System.out.println();
		  
		  System.out.println(" Child Name = " +cname);
		 
		  System.out.println(" Child ID = " +cid);
		  
	 }
	  
   }

public class InheritanceClass {

	public static void main(String[] args) {
		
		Child2 obj = new Child2();
		
		obj.display();
		
	 }

  }
