

package in.neha;

import java.util.ArrayList;

import java.util.Collection;

import java.util.Collections;

import java.util.Iterator;

public class ProductMain {

	public static void main(String[] args) {
		
		Product p1 = new Product(123, "TV",  45300.23f);
		
		Product p2 = new Product(155, "LCD", 76320.11f);
		
		Product p3 = new Product(653, "LED", 47820.00f);
		
		Product p4 = new Product(435, "Fridge", 17208f);
		
	
	  ArrayList<Product> arob = new ArrayList<Product>();
	 
	  arob.add(p1);
	  
	  arob.add(p2);
	  
	  arob.add(p3);
	  
	  arob.add(p4);
	  
	  //System.out.println(arob);
	  
	 	            
	 	      // sort By Product Name
	 	            
	 	       SortByProductName pn = new SortByProductName();
	 	       
	 	       Collections.sort(arob,pn);
	 	        
	 	       System.out.println(" Sorting Based On Product Name ");
	 	       
	 	       
	 	       Iterator<Product> pit = arob.iterator();
	 	        
	 	       System.out.println("PID\tPNAME\tPPRICE");
	 	        
	 	            while(pit.hasNext()) {
	 	        	   
	 	        	   Product pt = pit.next();
	 	        	   
	 	        	   System.out.println(pt.pid+"\t"+pt.pname+"\t"+pt.pprice);       	   
	 	            
	 	       }
	 	            
	 	       
	 	       // sort by product ID
	 	        
	 	         SortByProductID pi= new SortByProductID();
	 	         
	 	         Collections.sort(arob, pi);
	 	         
	 	         System.out.println(" Sorting Based on Product Id ");
	 	         
	 	         
	 	          Iterator<Product> pit2 = arob.iterator();
	 	          
	 	          System.out.println("PID\tPNAME\tPPRICE");
	 	          
	 	             while(pit2.hasNext()) {
	 	                
	 	                Product pt1 = pit2.next();
	 	                
	 	                System.out.println(pt1.pid+"\t"+pt1.pname+"\t"+pt1.pprice);   
	 	            
	 	      
	           }  
	 	    
	 	       
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	        	   
	 	      }
	
	     }

	
	
  
