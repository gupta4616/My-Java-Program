

package in.neha1;

import java.util.Iterator;

import java.util.LinkedHashSet;

public class LinkedHashSetMain {

	public static void main(String[] args) {
		
		 LinkedHashSet<String> hob = new LinkedHashSet<String>();
			
		  hob.add("Neha");
			
		  hob.add("Neha");
			
		  hob.add("Urmi");
			
		  hob.add("Priti");
			
		  hob.add("Anu");
			
		   System.out.println(hob);
			
				
			//itrator
			
			Iterator<String> sit = hob.iterator();
		
			  while(sit.hasNext()) {
				  
				  System.out.println(sit.next());
			
		 }
				
		  LinkedHashSet<Integer> iob = new LinkedHashSet<Integer>();
			
		   iob.add(531);
			
		   iob.add(988);
			
		   iob.add(463);
			
		   iob.add(343);
			
		   iob.add(583);
			
		   System.out.println(iob);
			
		 
			//itrator
			
			Iterator<Integer> sit1 = iob.iterator();
			
			  while(sit1.hasNext()) {
				  
				  System.out.println(sit1.next());
				  
		 }
			
	  }
		
   }
