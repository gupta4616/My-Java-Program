

package in.neha1;

import java.util.Iterator;

import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		
	    TreeSet<String> tob = new TreeSet<String>();
		
		tob.add("Neha");
		
		tob.add("Urmi");
		
		tob.add("Priti");
		
		tob.add("Anu");
		
		System.out.println(tob);
		
		
		   //itrator
		
	       Iterator<String> sit = tob.iterator();
			
			  while(sit.hasNext()) {
					  
				 System.out.println(sit.next());
				
		     }
			  
			  
		   TreeSet<Integer> iob = new TreeSet<Integer>();
				
		   iob.add(531);
				
		   iob.add(988);
				
		   iob.add(463);
				
		   iob.add(343);
				
		   iob.add(583);
				
		   System.out.println(iob);
				
				
		       //itrator
				
				Iterator<Integer> sit1 = iob.iterator();
				
				   while(sit1.hasNext()) {
					  
					  System.out.println(sit1.next());
					  	
		 }
				
      }
			
   }   

 