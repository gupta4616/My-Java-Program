

package in.neha1;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetMain {

	public static void main(String[] args) {
		
       HashSet<String> sob = new HashSet<String>();
		
		sob.add("Neha");
		
		sob.add("Neha");
		
		sob.add("Urmi");
		
		sob.add("Priti");
		
		sob.add("Anu");
		
		System.out.println(sob);
		
		
		//itrator
		
		Iterator<String> sit = sob.iterator();
	
		  while(sit.hasNext()) {
			  
			  System.out.println(sit.next());
		
		 }
			
		HashSet<Integer> iob = new HashSet<Integer>();
		
		iob.add(531);
		
		iob.add(988);
		
		iob.add(463);
		
		iob.add(343);
		
		iob.add(583);
		
		System.out.println(iob);
		
	 
		//itrator
		
		Iterator<Integer> sit1 = iob.iterator();
		
		  while(sit1.hasNext()) {
			  
			  System.out.println(sit1.next());
		
		 }
		
	  }
	
    }
