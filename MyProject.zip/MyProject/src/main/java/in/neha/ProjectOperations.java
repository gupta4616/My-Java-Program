

package in.neha;

import java.sql.Connection;

import java.sql.Date;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.Scanner;

public class ProjectOperations {
      
    private static Connection myconn;
	
	private static PreparedStatement pst=null;

	private static ResultSet rs;
	
	
	   //Course List

        public static void courseList() throws SQLException {
		
		myconn=ProjectConnections.getConnections();
		
		String selsql="select * from Courses";
		
		pst=myconn.prepareStatement(selsql);
		
		ResultSet rs = pst.executeQuery();
		
		System.out.println("EDUBRIDGE COURSE LIST");
		
		System.out.println("Course_No \t Course_Fees \t Total_Hours \t Course_Name");
		
		System.out.println("____________________________________________________________________________________________________________________");
		
	       while(rs.next()) {
			
			int no=rs.getInt("Course_No");
			
			String cn=rs.getString("Course_Name");
			
			int fee=rs.getInt("Course_Fees");
			
			String time = rs.getNString("Total_Hours");
	
			System.out.println(no+"\t\t"+fee+"\t\t"+time+"\t\t"+cn);	
			
		  }
		
	    }
             
	
	     // For Admin
        
	
	       //Display 
	
	         public static void displayAllStudent() throws SQLException {
	    		
	    		myconn=ProjectConnections.getConnections();
	    		
	    		String selsql="select * from studentinformation";
	    		
	    		pst=myconn.prepareStatement(selsql);
	    		
	    		rs=pst.executeQuery();
	    		
	    		System.out.println("Student_Id \t Student_Name \t Mobile_Number \t DOB  \t Gender \t Address \t Email  \t Education \t Course_No");
	    		
	    		while(rs.next()) {
	    			
	    			int id = rs.getInt("Student_Id");
	    			
	    			String sn = rs.getString("student_Name");
	    			
	    			String mail = rs.getString("Email");
	    			
	    			String mono = rs.getString("Mobile_Number");
	    			
	    			String DOB = rs.getString("DOB");
	    			
	    			String gen = rs.getString("Gender");
	    			
	    			String add = rs.getString("Address");
	    			
	    			String edu = rs.getString("Education");
	    			
	    			int cno = rs.getInt("Course_No");
	    			
	     System.out.println(id+"\t\t"+sn+"\t\t"+mono+"\t"+DOB+"\t"+gen+"\t"+add+"\t\t"+mail+"\t\t"+edu+"\t\t"+cno);	
	    			
	    		}
	    		
	    	 }
	    		
	       
	    	
	    
	           //Delete 
	    
	         public static void deleteStudent() throws SQLException {
	         	 
	         myconn=ProjectConnections.getConnections();
	          	
	         int id;
	          	
	         Scanner sc=new Scanner(System.in);
	      		
	            System.out.println("Enter Student_Id to delete record");
	      	    id=sc.nextInt();
	      	
	      		String sel="select * from StudentInformation where Student_Id=?";
	      		
	      		pst=myconn.prepareStatement(sel);
	      	
	      		pst.setInt(1, id);
	      		
	      		rs=pst.executeQuery();
	      	
	      		if(rs.next()) {
	      		
	      		String del="delete from StudentInformation where Student_Id=?";
	      		
	      		pst=myconn.prepareStatement(del);
	      		
	      		pst.setInt(1,id);
	      		
	      		int rv = pst.executeUpdate();
	      		
	      		if(rv >0) {
	      			
	      			System.out.println("Record is Deleted");
	      			
	      		}
	      		
	      		else {
	      			
	      			System.out.println("ERROR!!!!!");
	      			
	      		}
	      		
	         }
	      		
	      		else {
	      			
	      			System.out.println("Student_Id "+id+" does not exists");
	      		}
	      		
	      	  }
	          
	         
	           //Update
	         
	           public static void updateStudent() throws SQLException {
	        	 
	        	 myconn=ProjectConnections.getConnections();
	         	
	        	 int id;
	        	
	             Scanner sc=new Scanner(System.in);
	    		 
	    		 System.out.println("Enter Student_id to update record"); 
	    		 id=sc.nextInt();
	    		 
	    		
	    			   
	    		 System.out.println("1.Change Your Mobile_number");
	    		 String mo=sc.next();
	    			   
	    		 System.out.println("Change Your Address");
	    		 String ad = sc.next();
	    		
	    		 String sel="select * from studentinformation where Student_Id=?";
	    		 
	    		 pst=myconn.prepareStatement(sel);
	    		
	    		 pst.setInt(1,id);
	    		 
	    		 rs=pst.executeQuery();
	    		 
	    		    if(rs.next()) {
	    		    	
	    			String upd="update studentinformation set Mobile_number=?, Address=? where Student_Id=?";
	    			
	    			pst=myconn.prepareStatement(upd);
	    			
	    			pst.setString(1, mo);
	    			
	    			pst.setString(2, ad);
	    			
	    			pst.setInt(3, id);
	    			
	    			int rv=pst.executeUpdate();
	    			
	    			if(rv>0) {
	    				
	    				System.out.println("Record is Updated");
	    				
	    			}
	    			
	    			else {
	    				
	    				System.out.println("ERRROR!!!!!!");
	    			}
	    			
	    		 } 
	    		    else {
	    		    	
	    		    	System.out.println("Student_Id"+id+" does not exists");
	    		}

	        }	
	    		   
	         
	    		
	         
	           // For Student
	           
	         
	            //Display Particular Record
	         
	           public static void displayParticularStudent() throws SQLException {
	        	   
	        	myconn=ProjectConnections.getConnections();
	          
	            Scanner sc = new Scanner(System.in);
	      	   
	      	   System.out.println("Enter Student_id to See Your Record"); 
    		   int id = sc.nextInt();
    		 
	      	   String sel="select * from studentinformation where Student_id=?";
	      	     
	      	     pst=myconn.prepareStatement(sel);
	      	     pst.setInt(1, id);
	      	     rs=pst.executeQuery();
	      	     
	      	     if(rs.next()) {
	      	       
	      	        System.out.println("Student_Id \t Student_Name \t Email \t\t Mobile_Number \t DOB \t Gender \t Address \t Education");
	      	        
	      	        int idd = rs.getInt("Student_Id");
	      				
	      			String name = rs.getString("Student_Name");
	      				
	      			String email = rs.getString("Email");
	      				
	      			String mono = rs.getString("Mobile_Number");
	      				
	      			String DOB = rs.getString("DOB");
	      			
	      			String gender = rs.getString("Gender");
	      				
	      			String address = rs.getString("Address");
	      				
	      			String education = rs.getString("Education");
	      			
	      			System.out.println(idd+"\t\t"+name+"\t\t"+email+"\t"+mono+"\t"+DOB+"\t"+gender+"\t"+address+"\t\t"+education);
	      				
	      	          }
	      	          
	      	        }
	      	     
	             
	          
	         
	             //Update Particular Record
	          
	             public static void updateParticularStudent() throws SQLException {
	            	 
	               myconn=ProjectConnections.getConnections();
	   	          
		              int id;
		          
		              String mono;
		              
		              String add = null;
		          
		             Scanner sc = new Scanner(System.in);
		    		 
		    		 System.out.println("Enter Student_id to update record"); 
		    		 id=sc.nextInt();
		    		
		    		 String sel = "select * from studentinformation where Student_Id=?";
		    		 pst=myconn.prepareStatement(sel);
		    		 
		    		 pst.setInt(1,id);
		    		 
		    		 rs=pst.executeQuery();
		    		 
		    		    if(rs.next()) {
		    		    	
		    		    System.out.println("Change Your Mobile number");
		    		    mono = sc.next();
		    		    
		    		    System.out.println("Change Your Address");
		    		    add = sc.next();
		    		    	
		    			String upd="Update studentinformation set Mobile_Number=?, Address=? where Student_Id=?";	
		    			
		    			pst = myconn.prepareStatement(upd);
		
		    			pst.setString(1, mono);
		    			
		    			pst.setString(2, add);
		    			
		    			pst.setInt(3, id);
		    			
		    		   int rs=pst.executeUpdate();
		    			
		    			if(rs>0) {
		    				
		    				System.out.println("Record is Updated");
		    				
		    			}
		    			
		    			else {
		    				
		    				System.out.println("ERRROR!!!!!");
		    			}
		    			
		    		 } 
		    		    else {
		    		    	
		    			   System.out.println("Student_Id"+id+" does not exists");
		    			   
		    		  }

		            }	
	             
	             
	               // Insert Record 
	             
	              public static void insetStudent() throws SQLException {
	             	
	               myconn=ProjectConnections.getConnections();
	             	
	                int id;
	             	
	             	String name;
	             	
	             	String mail;
	             	
	             	String mono;
	             	
	                String DOB ;
	             	
	             	String gender;
	             	
	             	String address;
	             	
	             	String edu;
	             	
	             	int no = 0;
	     	
	                Scanner sc=new Scanner(System.in);
	                
	                System.out.println("Enter Your Student Id");
	                id = sc.nextInt();
	         
	         		System.out.println("Enter Your Full Name");
	         		name = sc.next();
	         		
	         		System.out.println("Enter Your EMAIL ID");
	         		mail = sc.next();
	         		
	         		System.out.println("Enter Your Mobile Number");
	         		mono = sc.next();
	         		
	         		System.out.println("Your DOB   (YYYY-MM-DD)");
	         		DOB = sc.next();
	         		
	         		System.out.println("Gender    (M/F)");
	         		gender = sc.next();
	         		
	         		System.out.println("Enter Your Current Address");
	         		address = sc.next();
	         		
	         		System.out.println("Edcucation");
	         		edu = sc.next();
	         		
	         		System.out.println("Enter Course_No Which One You Choose");
	         		no = sc.nextInt();
	         		
	 
	               String sel = "insert into StudentInformation values(?,?,?,?,?,?,?,?,?)";
	         		
	         		pst=myconn.prepareStatement(sel);
	         		
	                pst.setInt(1, id);
	                
	         		pst.setString(2, name);
	         		
	         		pst.setString(3, mail);
	         		
	         		pst.setString(4, mono);
	         		
	         	    pst.setString(5, DOB);
	         		
	         		pst.setString(6, gender);
	         		
	         		pst.setString(7, address);
	         		
	         		pst.setString(8, edu);
	         		
	         		pst.setInt(9,no);
	         		
	         		int rv=pst.executeUpdate();
	         	
	         		if(rv>0) {
	         			
	        			System.out.println("HORAYYY!!!!!! Admission Confirm");
	        			
	        	}
	         		else {
	         			
	        			System.out.println("Not Confirm");
	           }
	         		      
	         }      
	                           
	              
     }
	    		             