

package in.neha;

import java.sql.Connection;

import java.sql.DriverManager;

public class ProjectConnections {
	
	private static Connection myconn;
	
	private static String driver = "com.mysql.cj.jdbc.Driver";
	
	private static String url = "jdbc:mysql://localhost:3306/project";
	
	private static String un = "root";
	
	private static String up = "root";
	
	
	 public static Connection getConnections() {
		 
		 try {
			 
			 Class.forName(driver);
			 
			 myconn = DriverManager.getConnection(url,un,up);
			 
			    if(myconn == null) {
			    	
			    	System.out.println("Connection Error");
			    	
			  }
			    
		   }
		 
		 catch(Exception e) {
			 
			 e.printStackTrace();
			 
	    }
		 
		return myconn;
			 
	   }

    }
