// collection Framework API combination of interfcae and classes    

package in.neha;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionInterface {

	public static void main(String[] args) {
		
		int array[] = new int [5];   //its taking a limit
			
		//int
		ArrayList<Integer> iob = new ArrayList<Integer>();	
		iob.add(10);
		iob.add(20);
		iob.add(30);
		iob.add(40);
		iob.add(50);
		
		System.out.println(iob);   // for dispaly
		
		   for(int i: iob) {          // for each loop or enhanced loop
			
			  System.out.println(i);
			
	  }
		   System.out.println();
		   
	     Iterator<Integer> it1 = iob.iterator();
	             
	         while(it1.hasNext()) {
	        	   
	        	   System.out.println(it1.next());
	        	   
	      }
	           
	  //float   
      ArrayList<Float> fob = new ArrayList<Float>();
      
      fob.add(12.34f);
      fob.add(13.45f);
      fob.add(123.34f);
      fob.add(8656.1f);
      fob.add(98.04f);
      
      System.out.println(fob);
		 
          for(float f: fob) {
    	  
    	      System.out.println(f);
    	  
      }
          System.out.println();
          
         Iterator<Float> it2 = fob.iterator();
          
	         while(it2.hasNext()) {
	        	   
	        	   System.out.println(it2.next());
	        	   
	      }
	           
      //double
      ArrayList<Double> dob = new ArrayList<Double>();
      
      dob.add(6736d);
      dob.add(45d);
      dob.add(66d);
      dob.add(67366d);
      dob.add(9836d);
         
      System.out.println(dob);
		 
         for(double d: dob) {
    	  
    	    System.out.println(d);
    	    
      }
         
         System.out.println();
         
         Iterator<Double> it3 = dob.iterator();
          
	         while(it3.hasNext()) {
	        	   
	        	   System.out.println(it3.next());
	        	   
	  }
	         
      //string
      ArrayList<String> sob = new ArrayList<String>();
         
      sob.add("Neha");
      sob.add("Monika");
      sob.add("Namrata");
      sob.add("Usha");
      sob.add("Aaru");
            
       System.out.println(sob);
   		 
          for(String s: sob) {
       	  
       	        System.out.println(s);
       	    
         }
          
          System.out.println();
          
          Iterator<String> it4 = sob.iterator();
           
 	         while(it4.hasNext()) {
 	        	   
 	        	   System.out.println(it4.next());
 	        	   
 	      }
 	         
       //char  
       ArrayList<Character> cob = new ArrayList<Character>();
       
       cob.add('A');
       cob.add('B');
       cob.add('C');
       cob.add('D');
       cob.add('E');
       
       System.out.println(sob);
       		 
           for(String s: sob) {
           	  
           	    System.out.println(s);
           	    
        }
          
           System.out.println();
           
           Iterator<Character> it5 = cob.iterator();
            
  	           while(it5.hasNext()) {
  	        	   
  	        	   System.out.println(it5.next());
  	        	   
  	    }	
	
	  }
 }
