// input different data of variable

package in.neha;

public class InputDatavariable {

	public static void main(String[] args) {
	
		int num = 50;
		
		float fval = 87.6f;
		
		double dval = 65.5;
		
	    char ch = 'N';
	    
	    String str = "Neha";
	      
	       System.out.println(" num = " + num);
	       
	       System.out.println(" float = " + fval);
	       
	       System.out.println(" doubl = " + dval);
	       
	       System.out.println(" char = " + ch);
	       
	       System.out.println(" string = " +str);
	     
	  }

  }
