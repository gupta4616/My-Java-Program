// additions of 2 numbers

package in.neha;

public class AdditionOfTwoNumbers {

	public static void main(String[] args) {
		
		 int num1,num2,sum,sub, prod;
		 
		 float div, mod;
		 
		  num1=45;
		  num2=54;
		  
	  sum = num1+num2;
	  System.out.println("The sum of "+num1 +" and "+num2 + " is " + sum);
	  
	  sub = num2-num1;
	  System.out.println("The diffrence of "+num2 +" and "+num1 + " is " + sub);
	  
	  prod = num1*num2;
	  System.out.println("The prod  of "+num1 +" and "+num2 + " is " + prod);
	  
	  div =(float) num2/num1;
	  System.out.println("The quotient of "+num1 +" and "+num2 + " is " + div);
	  
	  mod = (float) num2%num1;
	  System.out.println("The remainder of "+num1 +" and  "+num2 + " is " + mod);
	  
	  
	 }

 }
