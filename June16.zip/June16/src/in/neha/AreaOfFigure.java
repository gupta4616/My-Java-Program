// area of given figures

package in.neha;

public class AreaOfFigure {

	public static void main(String[] args) {
		
    double length,breadth,radius,side,pi,height,base,area;
    
    length=56;
    breadth=12;
    side=54;
    radius=6;
    pi=3.14;
    height=14;
    base=12;
    
     area=side*side;
     System.out.println("Area of Square of side=" +side+" is "+area);
  
     area=length*breadth;
     System.out.println("Area of reactangle of length=" +length+ " and breadth="+breadth+ " is "+area);
     
     area=pi*radius*radius;
     System.out.println("Area of circle of radius=" +radius+" is "+area);
     
     area=(base*height)*2;
     System.out.println("Area of triangle of base=" +base+ " height= " +height+" is "+area);
     
     
	 }

  }
