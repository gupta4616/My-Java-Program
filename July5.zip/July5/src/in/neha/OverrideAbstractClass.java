

package in.neha;

abstract class Bank {
	
	abstract float rateofintrest();
	
       void display() {
    	  
    	   System.out.println(" Bank  Abstract Class ");
    	   
      }
       
   }

class SBI extends Bank {

	@Override
	float rateofintrest() {
		
		return 8.5f;
		
	  }
	
	}

class HDFC extends Bank {

	@Override
	float rateofintrest() {
		
		return 7f;
		 
	  }
	
    }

class ICICI extends Bank {

	@Override
	float rateofintrest() {
		
		return 5.9f;
		
	  }
	
    }

public class OverrideAbstractClass {

	public static void main(String[] args) {
		
		//Bank bob = new Bank();
		
		SBI sob = new SBI();

		System.out.println(" Rate of Intrest of SBI  " + sob.rateofintrest() + " Rs ");
		
		//sob.display();
		
		
		HDFC hob = new HDFC();
		
		System.out.println(" Rate of Intrest of HDFC " + hob.rateofintrest() + " Rs ");
		
		//hob.display();
		
		
		ICICI iob = new ICICI();
		
		System.out.println(" Rate of Intrest of ICICI " + iob.rateofintrest() + " Rs ");
		
		//iob.display();

	  }

  }
