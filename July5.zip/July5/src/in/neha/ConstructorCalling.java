

package in.neha;

abstract class Abstractclass1 {
	
	  private int data;


	   public Abstractclass1(int data) {
		
		//super();
		   
		System.out.println(data+10);
		
	    }
	  
   }

class Abstractclass2 extends Abstractclass1{

	public Abstractclass2(int data) {
		
		super(data);
		
	   }
	
   }

public class ConstructorCalling {

	public static void main(String[] args) {
		
		Abstractclass2 obj = new Abstractclass2(20);
		
	  }

  }
