

package in.neha;

abstract class abstractclass {
	
	 void display() {
		 
		 System.out.println(" Display Method ");
		 
	  }
	 
   }

public class AbstractKeywords extends abstractclass  {

	public static void main(String[] args) {
		
		//abstractclass  ob = new abstractclass ();
		
		AbstractKeywords obj = new AbstractKeywords();
		
		obj.display();

	  }

  }
