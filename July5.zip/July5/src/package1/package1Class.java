// access specifiers 

package package1;

import package2.Package2Class;

public class package1Class extends Package2Class {

	public static void main(String[] args) {
		
		
		// within package 
		
		MyClass ob = new MyClass();  
		
		System.out.println(ob.publicvalue1);
		
		System.out.println(ob.protectedvalue1);
		
		System.out.println(ob.defaultvalue1);
		
	
		
		// another package but obj create as same package name
		
		package1Class obj = new package1Class();
		
		System.out.println(obj.publicvalue2);
		
		System.out.println(obj.protectedvalue2);
		
		// default data cant be acess in another package
		
	
		
		// another package and obj create as another package name
		
		Package2Class pob = new Package2Class();
		
		System.out.println(pob.publicvalue2);
		
		// defalut, protected can not access

	  }

   }
