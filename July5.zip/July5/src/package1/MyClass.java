

package package1;

public class MyClass { 
	
	   public int publicvalue1;
	   
	   private int privatevalue1;
	   
	   protected int protectedvalue1;
	   
	   int defaultvalue1;

	   
	    public MyClass() {   // constructor
	    	
	    	publicvalue1 = 10;
	    	
	    	privatevalue1 = 20;
	    	
	    	protectedvalue1 = 30;
	    	
	    	defaultvalue1 = 40;
	    	
	   }
	    
	       
	    public void method() {
	    	
	    	System.out.println(privatevalue1); // access only in class itself 
	    	
	    }
	    
    }
	    
