package package2;

public class Package2Class {
	
	  public int publicvalue2;
	  
	  private int privatevalue2;
	  
	  protected int protectedvalue2;
	  
	  int defaultvalue2;
	  
	  
	  public Package2Class() {  // constructor
		  
		  publicvalue2 = 100;
		  
		  privatevalue2 = 200;
		  
		  protectedvalue2 = 300;
		  
		  defaultvalue2 = 400;
		  
	  }
	
    }

