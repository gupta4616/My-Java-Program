package in.neha;

class Bank {
	
	 int amount;
	 
	  Bank() {
	 
		amount = 1000;
	
     }
	  
	 synchronized void withDraw(int wamount) throws InterruptedException {
		 
		 if(wamount>amount) {
			 
			 System.out.println(" Insufficient Balance ");
			 
			 System.out.println(" First deposite the amount ");
			 
			 wait();
		 }
		 
		   amount = amount-wamount;
		   
		   System.out.println(" Your amount after deposite " +amount);
		   
	    }
	 
	  synchronized void deposite(int damount) {
		  
		  amount = amount+damount;
		  
		  System.out.println(" Your amount after deposite " +amount);
		  
		  notify();
		  
	  }
	  
   }

public class BankMain {

	public static void main(String[] args) {
		
		Bank obj = new Bank();
		
		   new Thread() {
			   
			   public void run() {
				   
				   try {
					obj.withDraw(2000);
					
				} 
				   catch (InterruptedException e) {
					
					e.printStackTrace();
					
				}
				   
			 }
			   
		   }.start();
		   
		   Thread t2 = new Thread() {
			   
			   public void run() {
				   
				   obj.deposite(2000);
				   
			   }
			   
		   };
		   
		   t2.start();
		   
	}

}
