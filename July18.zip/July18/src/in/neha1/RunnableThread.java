

package in.neha1;

class RunnableThraed implements Runnable {
	
	@Override
	public void run() {
		
		System.out.println(" Runnable Threds ");
		
		 try {
			 
			Thread.sleep(2000);
			
		  } 
		 
		 catch (InterruptedException e) {
		
			    e.printStackTrace();
			    
		 }
		
	  }
		
  }

public class RunnableThread {

	public static void main(String[] args) throws InterruptedException {
		
		RunnableThraed obj = new RunnableThraed();
		
		obj.run();
		
		
		Thread tob = new Thread(obj);  // create a thread object in runnable 
		
		tob.start();
		
		tob.join();
		
       }

   }
