

package in.neha1;

class ExtendingThread extends Thread {
	
	  public void run() {
		  
		 // for(int i=1; i<=10; i++) {
			  
			  System.out.println(" Extending Thread ");
			  
			  System.out.println(Thread.currentThread());
			  
		  }
		  
	  }
	  
  // }

public class ExtendsThread {

	public static void main(String[] args) {
		
		ExtendingThread obj = new ExtendingThread();
		
		obj.setName("t1");
		
		obj.start();
		
		//obj.setPriority(1); //least
		
		obj.setPriority(Thread.MAX_PRIORITY); //10
		
		obj.setPriority(Thread.MIN_PRIORITY); //1
		
		obj.setPriority(Thread.NORM_PRIORITY); //5
		
		
		ExtendingThread obj1 = new ExtendingThread();
		
		obj1.setName("t2");
		
		obj1.start();
		
		obj.setPriority(10); //highest

	 }

  }
