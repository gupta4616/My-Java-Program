// print the 100 natural number using while loop

package in.neha;

public class printNaturalNumber {

public static void main(String[] args) {
	 
		int i=1;
		
		while(i<=100) {
			
			System.out.println(i);
				
			i++;
		}

	}

}
