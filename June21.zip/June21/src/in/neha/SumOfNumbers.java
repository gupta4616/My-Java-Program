// Sum of numbers 

package in.neha;

import java.util.Scanner;

public class SumOfNumbers {

public static void main(String[] args) {
	
	int n;
	
	Scanner sc = new Scanner(System.in);
		
    System.out.println(" Enter the value of n ");
    n = sc.nextInt();
    
    int sum=0;
    int i;
    i=1;
    
    while(i<=n) {
    	
    	sum = sum+i;
    	i++;
    	
    }
    	
    System.out.println(" Sum " +sum);
    
	}

}
