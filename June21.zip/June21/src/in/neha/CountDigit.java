// count the number of digits 

package in.neha;

import java.util.Scanner;

public class CountDigit {

public static void main(String[] args) {
	
	int count=0;
	int num;
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println(" Enter the number = ");
	num = sc.nextInt();
	
	while(num>0) {
	  
		num=num/10;
		++count;
	}

	System.out.println(" Number of digits are " +count );
	}

}
