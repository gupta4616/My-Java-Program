// the number is armstrong or not 

package in.neha;

import java.util.Scanner;

class ArmstrongNumber{
	
	int num,temp;
	
	void inputData() {
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println(" Enter the number ");
	num=sc.nextInt();
	
	}
	
	void CheckArmstrong() {
		
		temp=num;
		int digit=0;
		int s=0;
		
		while(temp>0) {
			digit = temp%10;
			s=s+(digit*digit*digit);
			temp=temp/10;		
		}
		
		if(num==s) {
			System.out.println( num+ " is armstrong number ");
		}
		
		else {
			System.out.println (num+ " is not armstrong number " );
		}
		
	}
}


public class ArmstrongNumbermain {

public static void main(String[] args) {
	
	ArmstrongNumber obj = new ArmstrongNumber();
	
	obj.inputData();
	obj.CheckArmstrong();
		

	}

}
