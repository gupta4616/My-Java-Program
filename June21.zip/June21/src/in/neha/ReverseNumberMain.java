// reverse the number using class and object

package in.neha;

import java.util.Scanner;

class Reverse{

  int d;
  int num;
  
   void inputData() {
	Scanner sc = new Scanner(System.in);
	System.out.println(" Enter the number ");
	num=sc.nextInt();

}

   void calculateData() {
	int rev=0;
	while(num>0) {
		d=num%10;
		System.out.print(d);
		rev=rev*10+d;
		num=num/10;
	}
}
   
     void displayData() {
	System.out.println(" Rev ");
	
}

}

public class ReverseNumberMain {

public static void main(String[] args) {
		
	Reverse ob = new Reverse();
	ob.inputData();
	ob.calculateData();
	ob.displayData();

	}

}
