// sum of 1 to 100 natural numbers 

package in.neha;

import java.util.Scanner;

public class SumOfNaturalNumber {

public static void main(String[] args) {

	int i=1;
	int sum=0;
	
	while(i<=100) {
		sum=sum+i;
		i=i+1;
	}
	
	System.out.println( " sum " +sum);
	
	}

}
