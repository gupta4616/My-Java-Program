// print the name using switch case

package in.neha;

public class printName {

public static void main(String[] args) {
	
		int i=1;
		
		while(i<=10) {
			
			System.out.println(" Neha ");
			
			i++;
		}
	    
		//System.out.println(" Name= "+i);
		
	}
	
}
