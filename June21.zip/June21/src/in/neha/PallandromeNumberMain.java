// given number is pallandrome or not 

package in.neha;

import java.util.Scanner;

class Pallandrome {
	
     int num,rev,d,temp;
	
	  void operation() {
		  
		  rev=0;
		  
		Scanner st = new Scanner(System.in);
		
		System.out.println(" Enter Number ");
		
		num = st.nextInt();
		
		//num = temp;
		
		while(num>0) {
			
			d = num%10;
			
			rev = rev*10+d;
			
			num = num/10;
		}
		
		 System.out.println(rev);
		 
	    }
	
	    void pallandrome() {
	    	
		  if (num==rev) {
			  
			  System.out.println(" Pallandrome Number ");
		  }
		  
		  else {
			  
			  System.out.println(" not Pallandrome Number ");
		  }		  
			 
		}
 	     
     }	  

public class PallandromeNumberMain {

public static void main(String[] args) {
	
	Pallandrome obj = new Pallandrome();
	
	obj.operation();
	
	obj.pallandrome();
	
	
	}

}
