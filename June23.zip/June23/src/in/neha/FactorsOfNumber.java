//factors of sum 

package in.neha;

import java.util.Scanner;

public class FactorsOfNumber {

public static void main(String[] args) {
	
     	int num;
	
	    Scanner sc = new Scanner(System.in);

	    System.out.println(" Enter the num to find factors of ");
	    num = sc.nextInt();
	    
	    for(int i =1; i<=num; i++) {
	    	if(num%i==0) {
	    		System.out.println(" " +i);
	    	}
	    	else {
	    		continue;
	    	}
	    }
	}

}
