//find the sum using for loop

package in.neha;

public class ForLoop {

public static void main(String[] args) {
	
	int i;
	int s=0;
	for (i=1; i<=10; i++) {
		s = s+i;
	}
	
	System.out.println(" sum = " +s);
	}

}
