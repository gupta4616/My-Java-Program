//find the prime number 

package in.neha;

import java.util.Scanner;

public class PrimeNumber1 {

public static void main(String[] args) {
	
	int num;
	int a=0;
	
	Scanner sc = new Scanner(System.in);
	
    System.out.println(" Enter a number ");
    num = sc.nextInt();
    
    for(int i=1; i<=num;i++) {
    	
    	if(num%i==0) {
    		a++;		
    	}
   }
    
    if(a==2) {
    	System.out.println(num+ " num is prime ");
   }
    
    else {
        System.out.println(num+ " num is not prime ");
   }	
    
 }

}


