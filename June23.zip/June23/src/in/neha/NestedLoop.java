// 

package in.neha;

public class NestedLoop {

public static void main(String[] args) {
	
	for(int i=1; i<=3; i++) {
		for(int k=1; k<=3; k++) {
			
			System.out.println(" i = " +i+ " and  k = " +k);		
			
		}
	}
		

	}

}
