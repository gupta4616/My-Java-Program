//

package in.neha;

import java.util.Scanner;

public class FindFibonacciSeries {

	public static void main(String[] args) {
	
		int terms, f1,f2,f3;
		f1=0;
		f2=1;
		
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter number of series=");
        terms = sc.nextInt();
        
        
        System.out.println(" fibonacci series ");
        
        System.out.println(f1);
        System.out.println(f2);
        
        for(int i=1; i<=terms; i++) {
        	f3=f1+f2;
        	
        	System.out.println(f3);
        	f1=f2;
        	f2=f3;
        }  
        
        System.out.println("Total= "+terms);
  
    }

	}


