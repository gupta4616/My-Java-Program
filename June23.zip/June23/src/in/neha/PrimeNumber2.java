//find prime number using the another method

package in.neha;

import java.util.Scanner;

public class PrimeNumber2 {

public static void main(String[] args) {

      int num;
      num =0;
      
      Scanner sc = new Scanner(System.in);
      
      System.out.println(" Enter the number ");
      num = sc.nextInt();
      
      boolean prime=true;
      
      for(int i=2; i<num; i++) {
    	  if(num%i==0) {
    		  prime=false;
    		  break;
    	  }
      }
      
      if (prime) {
    	  System.out.println(num+ " Num is prime ");
      }
      else {
    	  System.out.println(num+ " Num is not prime ");
      }
	}

}
