

package in.neha;

class MyThread extends Thread {
	
	  public void run() {
		
		 for(int i=1;i<=5;i++) {
			
			System.out.println(Thread.currentThread() +"i="+i);	
			
		}
		
		  try {
			
			Thread.sleep(10000);
			
		}
		
	      catch (InterruptedException e) {
		   
			e.printStackTrace();
			
		}
		
	 }
	
  }


public class ThreadMain {

	public static void main(String[] args) throws InterruptedException {
		
		MyThread tob=new MyThread(); 
		
		MyThread tob1=new MyThread(); 
		
		tob.setName("first");
		
		System.out.println("tob is Alive "+tob.isAlive());
		
		tob.start();//
		
		System.out.println("tob is Alive "+tob.isAlive());
		
		
		System.out.println("tob1 is Alive "+tob1.isAlive());
		
		tob.join();  //
		
		System.out.println("tob is Alive "+tob.isAlive());
		
		tob1.setName("second");
		
		tob1.start();//
		
		System.out.println("tob1 is Alive "+tob1.isAlive());
			
	   }

	}

