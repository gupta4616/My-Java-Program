

package in.neha;

class FirstThread implements Runnable {

	@Override
	public void run() {
		
		for(int i=1; i<=10; i++) {
			
			System.out.println(Thread.currentThread() +"i"+i);
			
			 try {
				
				Thread.sleep(1000);
				
		    } 
			
			 catch (InterruptedException e) {
				
				     e.printStackTrace();
				     
			 }
			
		 }
		
	 }
	
 }


public class ThreadMainApp {

	public static void main(String[] args) throws InterruptedException {
		
		FirstThread obj = new FirstThread ();
		
		FirstThread obj1 = new FirstThread ();
		
		Thread tob = new Thread(obj);
		
		Thread tob1 = new Thread(obj1);
		
		obj.run();
		
		tob.join();
		
		obj1.run();
		
		
		tob.setName("First");
		
		tob1.setName("Second");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
