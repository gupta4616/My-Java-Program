package in.neha;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class TreeMapMain {

	public static void main(String[] args) {
		
		TreeMap<String, String> tob = new TreeMap<String, String>();
		int n;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number of students ");
		n = sc.nextInt();
		
		System.out.println("Enter Phone Number" + " Enter Your Name");
		
		  for(int i=0; i<n; i++) {
			  
			  String phnno = sc.next();
			  
			  String name = sc.next();
			  
			  tob.put(phnno, name);
			  	  
		   }
		  
		   for(Map.Entry<String, String> eob:tob.entrySet() ) {
				
				System.out.println(eob.getKey()+"\t" +eob.getValue());
				
		  }

	}

}
