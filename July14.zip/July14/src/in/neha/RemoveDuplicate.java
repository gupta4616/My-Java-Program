package in.neha;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class RemoveDuplicate {

	public static void main(String[] args) {
		
		ArrayList<String> aob = new ArrayList<String>();
		
		aob.add("Neha");
		
		aob.add("Neha");
		
		aob.add("Divya");
		
		aob.add("Priti");
				
		//System.out.println(aob);
		
		
       TreeSet<String> tob = new TreeSet<String>();
       
        
         Iterator<String> it = aob.iterator();
         
              while (it.hasNext()) {
		
            	  tob.add(it.next());
            	  
         }
              
              System.out.println(tob);

	    }

     }
