package in.neha;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class TreeSetMain {

	public static void main(String[] args) {
		
		TreeSet<String> sob = new TreeSet<String>();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter the numbers ");
		
		int n = sc.nextInt();
		
		System.out.println(" Enter the name ");
		
		    for(int i=0; i<n; i++) {
			 
			   String name = sc.next();
			 
			   sob.add(name);
			 
	     }
		
		 Iterator<String> it = sob.iterator();
		 
		  while(it.hasNext()) {
			  
			  System.out.println(it.next());
			  
	    }	

	}

}
