package in.neha;

import java.util.Iterator;

import java.util.LinkedList;

import java.util.Scanner;

public class LinkedListMain {

	public static void main(String[] args) {
		
		LinkedList<Integer> iob = new LinkedList<Integer>();
		
		int num,add;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter numbers ");
		num = sc.nextInt();
		
		System.out.println(" Enter   " +num + " Elements");
		
		   for(int i=0; i<num; i++) {
			 
			  iob.add(sc.nextInt());	 
			 
		 }
		 
		   Iterator<Integer> it = iob.iterator();
		 
		         while(it.hasNext()) {  
		   
		          System.out.println(it.next());
		
		}	
			
	 }
	
  }