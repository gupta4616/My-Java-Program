// implement is thread class by using implements Runnable

package in.neha2;

class MyFirstClass implements Runnable{
	
	@Override
	
	public void run() {
		
		for(int i=1;i<=5;i++) {
			
		System.out.println(Thread.currentThread());
		
	   }
		
	}


public class Threadsmain {

	public static void main(String[] args) {
		
	    System.out.println(Thread.currentThread());
		
		FirstClass obj=new FirstClass();
		
		FirstClass obj1=new FirstClass();
		
		//obj.setName("FirtsThread");   // to change the name
		
		//obj1.setName("Second Thread");
		
		//obj.start();
		
		//obj1.start();
		
		obj.run();    // only use in runnable class
		
		obj.run();
		
	 }
		
	}

}


