// extends the thread class by using extends thread

package in.neha2;

class FirstClass extends Thread{
	
	@Override
	
	public void run() {
		
		for(int i=1;i<=5;i++) {
			
		System.out.println(Thread.currentThread());
		
	   }
		
	}
	
 }

public class ThreadMain {

	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread());
		
		FirstClass obj=new FirstClass();
		
		FirstClass obj1=new FirstClass();
		
		//obj.setName("FirtsThread");
		
		//obj1.setName("Second Thread");
		
		obj.start();   //use in thread class
		
		obj1.start();
		
	 }
	
  }

