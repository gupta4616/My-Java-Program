

package in.neha;

interface One {
	
	void method1();
	
 }

interface Two {
	
	void method2();
	
 }

interface Three extends One, Two {
	
	void method3();
	
 }

class Hello {
	
 }

class Hi {
	
 }
class InterfaceClass extends Hello implements Three {       // cant extent other than 1 class 

	@Override
	public void method1() {
		
		System.out.println(" Method 1 ");
	
	}

	@Override
	public void method2() {
		
		System.out.println(" Method 2 ");
			
	}

	@Override
	public void method3() {
		
		System.out.println(" Method 3 ");
			
	}
	
  }
	
public class InterfaceOfExtend {

	public static void main(String[] args) {
		
		InterfaceClass obj = new InterfaceClass();
		
		obj.method1();
		
		obj.method2();
		
		obj.method3();

	}

  }
