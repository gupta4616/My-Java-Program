package in.neha;

public class MultipleTryAndMultipleCatchBlock {

	public static void main(String[] args) {
		
		int a = 10 , b = 0 ,  c = 0;
		
		int array[] = new int[4];
		
		try {
			
			c = a/b;
			
		}
		
        catch(ArithmeticException p) {
	      
        	//System.out.println(p);
        	
        	 p.printStackTrace();
        	
        	 System.out.println(p.getMessage());
			
		}
		
		try {
			
			array[5] = 20;
			
		}
		
		catch(ArrayIndexOutOfBoundsException q) {
			
			q.printStackTrace();
			
			System.out.println(q.getMessage());
		}

	}

}
