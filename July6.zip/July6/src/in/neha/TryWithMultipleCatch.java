

package in.neha;

public class TryWithMultipleCatch {

	public static void main(String[] args) throws Exception {
		
		int a = 10 , b = 2 , c = 0 ;
		
		int array[] = new int[5];
		
		System.out.println(" Before Opration ");
		
		try {
			
			c = a/b;
			
			array[7] = 55;
			
			System.out.println(array[7]);
		}
		
		catch(ArithmeticException e) {
			
			e.printStackTrace();
			
		}
		
		catch(ArrayIndexOutOfBoundsException e) {
			
			e.printStackTrace(); // 
			
			System.out.println(e.getMessage()); //
			
		}

	}

}
