

package in.neha;

class singletoneClass {

    public static singletoneClass sob;
    
    private singletoneClass() {    //constructor
    	
    	System.out.println(" Constrctor of singletone Class ");
    	
    }
    
    public static singletoneClass  getsingletoneClassobject() {
		
    	 sob = new singletoneClass();
    	 
    	 return sob;  	
    	
    }
    
    public void display() {
    	
    	System.out.println(" Display Method ");
    	
    }

  }


public class SingletoneClassMain {

	public static void main(String[] args) {
		
		singletoneClass ob = singletoneClass.getsingletoneClassobject();
		
		ob.display();

	}

  }
