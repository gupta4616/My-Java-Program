

package in.neha;

public class ExceptionMain {

	public static void main(String[] args) {
		
		/* int a = 20, b = 5, c = 0;
		 
	     c = a/b;
	     
	     System.out.println(c);
		
	  } */

	    int x = 10, y = 0, z = 0;
	    
	    int array[] = new int[4];
	    
	      System.out.println(" Before Division ");
	      
	     try {
	    	 
	    	 z = x/y;
	    	 
	       }
	     
	     catch (ArithmeticException a) {
	    	 
	    	System.out.println(" catch will execute only when run time error occures ");
	    	
	    	a.printStackTrace();
	    	
	    	System.out.println(a);
	   
	     }
	     
	     finally {
	    	 
	    	 System.out.println(" Finally block is optional ");
	    	 
	    	 System.out.println(" Finally execute always ");
	    	 
	     }
	     
	      System.out.println(" After Division " +z);
	     
        }
	
  }


     