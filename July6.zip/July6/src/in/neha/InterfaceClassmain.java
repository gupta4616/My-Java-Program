

package in.neha;

interface Myinterface1 {
	
	  int value = 10;  //
	  
	 void interfaceMethod1();
	 
	 abstract void interfaceMethod();  
	
	 void interfaceMethod2();
	 	 
  }

class Myinterface2 implements Myinterface1 {

	@Override
	public void interfaceMethod1() {
		
		//value = value +10;  
		
		System.out.println(" Display Method 1 " +value);
		
	}

	@Override
	public void interfaceMethod() {
		
		System.out.println(" Display ");
		
	}

	@Override
	public void interfaceMethod2() {
		
		System.out.println(" Display Method 2 ");
		
	}
	
  }

public class InterfaceClassmain {

	public static void main(String[] args) {
		
		 //Myinterface1 ob = new  Myinterface1();
		
		 Myinterface2 obj = new  Myinterface2();
		 
		 obj.interfaceMethod1();
		 
		 obj.interfaceMethod2();
		 
		 obj.interfaceMethod();

	}

  }
