package in.neha;

public class Program5 {

	public static void main(String[] args) {
		int num =0;	
		
		while (num<5) {
			
			num++;
			
			System.out.println(num);
			
		}

	}

}
