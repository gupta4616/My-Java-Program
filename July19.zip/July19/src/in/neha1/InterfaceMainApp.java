

package in.neha1;

interface MyInterfaceApp1 {
	
	 void method1();
	 
	 void method2();

	default void message1() {
		 
		 System.out.println("Myinterface1");
		 
	 }
	 
  }

interface MyInterfaceApp2 {
	
	 void method2();
	 
	 default void message2() {
		 
		 System.out.println("Myinterface2");
		 
	 }
	 
   }

class MyClass1 implements MyInterfaceApp1,MyInterfaceApp2 {

	@Override
	public void method2() {
		
		System.out.println("Method2");
		
	}

	@Override
	public void method1() {
		
		System.out.println("Method1");
		
	}
		
 }


public class InterfaceMainApp {

	public static void main(String[] args) {
		
		MyClass1 ob = new MyClass1();
		
		ob.message1();
		
		ob.message2();
		
		ob.method1();
		
		ob.method2();
			
	}

 }
