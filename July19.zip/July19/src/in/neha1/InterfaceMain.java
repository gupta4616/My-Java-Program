// java 8 features for interface 

package in.neha1;

interface MyInterface {
	
	  void Func();  //public abstact 
	        
	  default void Function() {
		  
		  System.out.println(" Default Method in Interface ");
		  
	  }
	  
	  static void Function1() {
		  
		  System.out.println(" Static Method in Interface");
		  
	  }
	  
  }

class MyClass implements MyInterface {

	@Override
	public void Func() {
		
		System.out.println(" Interface Abstract Method ");
		
	}
	
   }


public class InterfaceMain {

	public static void main(String[] args) {
		
		MyClass obj = new MyClass();
		
		obj.Func();
		
		obj.Function();
		
		
		MyInterface.Function1(); //static method calling 
		
	 }

  }
