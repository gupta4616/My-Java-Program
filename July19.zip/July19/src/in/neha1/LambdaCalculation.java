

package in.neha1;

@FunctionalInterface
interface AddInt {
	
	 int add(int i,int j);
	 
  }

@FunctionalInterface
interface subInt {
	
	 int diff(int i,int j);
	 
  }

@FunctionalInterface
interface mulInt {
	
	 int mul(int i,int j);
	 
  }


public class LambdaCalculation {

	public static void main(String[] args) {
		
		AddInt aob =(i,j)->i+j;
		
		System.out.println("sum =" +aob.add(3, 9));
		
		
		subInt sob =(i,j)->i-j;
		
		System.out.println("diff =" +sob.diff(7, 6));
		
		
		mulInt mob =(i,j)->i*j;
		
		System.out.println("Mul =" +mob.mul(3, 8));
		
	}

  }
