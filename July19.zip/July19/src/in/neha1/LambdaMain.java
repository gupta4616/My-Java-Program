//functional interface without argument

package in.neha1;

@FunctionalInterface
interface LambdaInterface {
	
	 void Function();
	
  }

public class LambdaMain {

	public static void main(String[] args) {
		
		    LambdaInterface ob = () -> {
			
			System.out.println(" Interface Function ");
			
		};
		
	 }

  }
