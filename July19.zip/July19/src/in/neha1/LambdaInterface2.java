

package in.neha1;

@FunctionalInterface
interface MyLambdainterface {
	
	 String Method (String s);
		 
  }

public class LambdaInterface2 {

	public static void main(String[] args) {
		
		MyLambdainterface ob=(s)->{
			
			return "Hello" +s;
			
	   };
		
		 String obj = ob.Method(" Neha ");
		
		 System.out.println(obj);
		
	 }

  }
