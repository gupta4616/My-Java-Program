

package in.neha1;

interface MyNewInterface {
	
	 void display(int i,String s);
	 
   }

public class NewClassMain {

	public static void main(String[] args) {
		
		MyNewInterface ob = (i,s)-> 
		
		System.out.println("Age = " +i + "Name = " +s);
		
		//System.out.println(" Hello ");
		
		ob.display(22, "Neha");
	
	 }

  }
