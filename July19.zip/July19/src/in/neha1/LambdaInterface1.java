// functional interface lambda exp with argument

package in.neha1;

@FunctionalInterface
interface CallInter {
	
	void myCallMethod(String s);
	
  }

public class LambdaInterface1 {

	public static void main(String[] args) {
		
		CallInter obj =(s)-> {
			
			System.out.println(" Hello Functional interface"+s);
			
		};
		
		obj.myCallMethod("Hello");
	}

  }
