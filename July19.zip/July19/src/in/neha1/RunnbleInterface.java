

package in.neha1;

public class RunnbleInterface {

	public static void main(String[] args) {
		
		 Runnable ob=() ->{
			 
		   System.out.println(" Run Method ");
			 
		 };
		 
		 Thread tob = new Thread(ob);
		 
		 tob.start();

	 }

  }
