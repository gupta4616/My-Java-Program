// calculate the area of circle using classes and object in the Encapsulation Concept 

package in.neha;

import java.util.Scanner;

class circle {
	  float radius;
	  float area;
	  
  void inputData() {
	   Scanner sc = new Scanner(System.in);
	   System.out.println(" Enter the radius");
	   radius =  sc.nextInt();
  }
  
  void calculateArea() {
	   float pi=3.14f;
	   area =pi*radius*radius;
  }
  
  void displayArea() {
	   System.out.println(" area of circle of radius " +radius+ " is "+area );
  }
  
    }

  public class EncapsulationConcept {
	  
  public static void main(String[] args) {
	  
	 //System.out.println(" main method ");
	  
	  circle ob = new circle();
	  circle ob1 = new circle();
      circle ob2 = new circle();
	  
      ob.inputData();
      ob.calculateArea();
      ob.displayArea();
      
      //ob1.inputData();
      //ob1.calculateArea();
      //ob1.displayArea();
      
      //ob2.inputData();
      //ob2.calculateArea();
      //ob2.displayArea();
      
  }
  
  }
