// check the number is even or odd using switch case

package in.neha;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
   
		int num;
		Scanner sc = new Scanner (System.in);
		
		System.out.println(" Enter number ");
		num = sc.nextInt();
		
		switch(num%2) {
		        
			case 0 :// (num%2==0)
				   System.out.println(num+ " is an even number ");
			       break;
			     			    
			case 1 : // (num%2==1)
				   System.out.println(num+ " is an odd number ");
			       break;
			       
			default : System.out.println(" Invalid input ");
		}

	}

}
