// check vowel or consonant  using  switch case

package in.neha;

import java.util.Scanner;

public class VowelOrConsonant {

	public static void main(String[] args) {
		
		char ch;
		
		Scanner st = new Scanner(System.in);
		
		System.out.println(" Enter the character ");
		ch = st.next().charAt(0);
		 
		switch(ch) {
		
		case 'a', 'A' :
			
		case 'e', 'E' :
			
		case 'i', 'I':
			
		case 'o', 'O':
			
		case 'u', 'U' : 
			     System.out.println(ch+ "  is vowel ");
			     break;
	    default : System.out.println(ch+ " is consonant");
	    
	   }
		
	}
	
}
