// print the student data using classes and object

package in.neha;

import java.util.Scanner;

class Student {
	 int Sid;
	 String Sname;
	 float Sfees;
	 
  void inputData() {
	 Scanner st = new Scanner(System.in);
	 
	 System.out.println(" Enter name ");
	 Sname = st.next();
	 
	 System.out.println(" Enter id ");
	 Sid = st.nextInt();
	 
	 System.out.println(" Enter fees ");
	 Sfees = st.nextFloat();
    }
    
    void displayData() {
      System.out.println(" Name " +Sname);
      System.out.println(" id " +Sid);
      System.out.println(" fees " +Sfees);
     }
     
}


    public class StudentInformation {

	public static void main(String[] args) {
	  
	  Student s = new Student();
	  s.inputData();
	  s.displayData();
	  
	  Student s1 = new Student();
	  s1.inputData();
	  s1.displayData();
	  
	  //System.out.println(" s ref " +s);
	  
     //System.out.println(" name =" +s.Sname + " id = " +s.Sid + " fees " +s.Sfees);
	  
	 //System.out.println(" s1 ref " +s1);
	  
	}

}
