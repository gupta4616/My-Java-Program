// display week of days by using switch concept

package in.neha;

import java.util.Scanner;

public class SwitchBreakConcept2 {

	public static void main(String[] args) {
		 String Day;
	
		Scanner st = new Scanner(System.in);
        
	    System.out.println(" Enter the day in week ");
	     Day = st.next();
	    
	    switch(Day) {
	    
	    case "sunday" : System.out.println(" Day one ");
                      break;
        
	    case "monday" : System.out.println(" Day two");
                       break;
        
	    case " tuesday" : System.out.println(" Day three ");
                        break;
        
	    case "wednesday" : System.out.println(" Day four");
                        break;
        
	    case "thursday" : System.out.println(" Day five ");
                        break;
        
	    case "friday" : System.out.println(" Day six ");
                        break;
	    
	    case "saturday" :System.out.println(" Day seven ");
                        break;
                        
        default : System.out.println(" Invalid input ");  
        
	    }
	}

}
