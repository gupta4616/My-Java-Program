//calculate area of figures using switch concept and class and object with (menu driven program)

 package in.neha;

import java.util.Scanner;

class Area {
	 int sqaureArea(int side) {		 
	   return side*side;
	 }
	 
	 
	 void rectangleArea(int l, int b) {
		System.out.println(" Area of rectangle =" +(l*b));
	 }
	 
	 
	 void triangleArea() {
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter base and height of a traingle ");
		   int base = sc.nextInt();
		   int height = sc.nextInt();
		   
		float A = (base*height)*2f;
		System.out.println("Area of triangle =" +A);
	 }
	 
	 
	 float circleArea() {
		 Scanner sc = new Scanner(System.in);
		 
		 System.out.println(" Enter radius of a circle ");
		 float radius = sc.nextFloat();
		 
		 return (3.14f*radius*radius);
	 }
	 
  public class AreasOfFigures {
	
  public static void main(String[] args) {
	  
	    int side;
	    Area a = new Area();
	    Scanner sc = new Scanner(System.in);
	  
	  System.out.println(" Enter your choice ");
	  
	  System.out.println(" 1. calculate area of square ");
	  
	  System.out.println(" 2. calculate area of rectangle ");
	  
	  System.out.println(" 3. calculate area of triangle ");
	  
	  System.out.println(" 4 . calculate area of circle ");
	  
	    int ch = sc.nextInt();
	    
	    switch(ch) {
	    case 1 : System.out.println(" Enter the side of square ");
	             side = sc.nextInt();
	             int A = a.sqaureArea(side);
	             
	             System.out.println(" Area of square =" +a);
	           break;
	           
	    case 2 : System.out.println(" Enter length and breadth of a reactangle ");
	             int le = sc.nextInt();
	             int br = sc.nextInt();
	             
	              a.rectangleArea(le, br);
	            break;
	             
	     case 3 : a.triangleArea();
	           break;
	           
	     case 4 : float A1 = a.circleArea();
	              System.out.println(" Area of circle = " +A1);
	            break;
	            
	     default : System.out.println(" Invalid output ");
	    }
	    
	  }
    }
  
}
