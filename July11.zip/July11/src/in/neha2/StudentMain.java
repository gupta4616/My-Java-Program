

package in.neha2;

import java.util.ArrayList;

import java.util.Comparator;

import java.util.Iterator;

import java.util.LinkedList;
		
public class StudentMain {

	public static void main(String[] args) {
		
       Student s1 = new Student(101, "Neha", 21, 7670.550f);
       
       Student s2 = new Student(102, "Urmi", 22, 3200.420f);
       
       Student s3 = new Student(103, "Monika", 26, 16450.33f);
       
       Student s4 = new Student(104, "Ravi", 18, 8890.3f);
       
       
       LinkedList<Student> lob = new LinkedList<Student>();
       
       lob.add(s1);
       
       lob.add(s2);
       
       lob.add(s3);
       
       lob.add(s4);	
       
       System.out.println(lob);
       
       System.out.println();
       
       //for each loop
       
         for(Student s: lob) {
			  
			  System.out.println(s);
			  
			  System.out.println();
			  
        }

	   // iterator
	   
	   Iterator<Student> sit = lob.iterator();
	   
	   System.out.println("sid \tsname \tage \tsfees");
	   
	         while(sit.hasNext()) {
	    	   
	    	  Student s = sit.next(); 
	    	  
	    	  System.out.println(s.sid+"\t"+s.sname+"\t"+s.age+"\t"+s.sfees);
	    	  
	    }   
	       
	 }

  }
