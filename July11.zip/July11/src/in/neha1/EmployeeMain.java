//Collections.sort(arr); //its not access in usedefine arraylist coz diff datatype

package in.neha1;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Iterator;

public class EmployeeMain {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(11, "Manoj", 2034.77f);
		
		Employee e2 = new Employee(12, "Kiran", 303774.434f);
		
		Employee e3 = new Employee(13, "Neha", 40344.89f);
		
		Employee e4 = new Employee(14, "Ravi", 50984.324f);
		
		Employee e5 = new Employee(15, "Anu", 70384.3434f);
		
	
	  ArrayList<Employee> arr = new ArrayList<Employee>();
	
	   arr.add(e1);
	   
	   arr.add(e2);
	   
	   arr.add(e3);
	   
	   arr.add(e4);
	   
	   arr.add(e5);
	   
	  // System.out.println(arr);
	   
	   //for each loop
	   
	    // for(Employee e: arr) {
			  
			  //System.out.println(e);
			  
	      // }
			    
	   // iterator
	   
	   Iterator<Employee> it = arr.iterator();
	   
	    System.out.println("Eid \tEname \tEsalary");
	   
	          while(it.hasNext()) {
	    	   
	    	     Employee e = it.next(); 
	    	  
	    	      System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
	    	      
	          }  
	    	      
	    	//sorted by Name
	          
	          EmpSortedByName ename = new EmpSortedByName();
	          
	          Collections.sort(arr,ename);
	    	      
	          System.out.println(" Sorting Based Name ");
	          
	          
	          Iterator<Employee> eit = arr.iterator();
	          
	          System.out.println("EID\tENAME\tESALARY");
	          
	              while(eit.hasNext()) {
	            	  
	            	   Employee em = eit.next();
	            	   
	            	   System.out.println(em.eid+"\t"+em.ename+"\t"+em.esalary);
	            	   
	              }
	                  
	         //sorted by salary
	              
	           EmpSortedBySalary esalary = new EmpSortedBySalary();
	           
	           Collections.sort(arr,esalary);
	           
	           System.out.println(" Sorting Based on Salary ");
	    	      
	           
	           Iterator<Employee> eit1 = arr.iterator();
		          
		        System.out.println("EID\tENAME\tESALARY");
		          
		             while(eit1.hasNext()) {
		            	  
		            	  Employee em1 = eit1.next();
		            	   
		            	  System.out.println(em1.eid+"\t"+em1.ename+"\t"+em1.esalary);
		            	   
		       } 
		             
	      }
	
     }
