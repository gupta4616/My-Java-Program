

package in.neha;

import java.util.ArrayList;

import java.util.Collections;

import java.util.Iterator;

public class ArrayListMain {

	public static void main(String[] args) {
	
		ArrayList<String> aob1 = new ArrayList<String>();
		
		aob1.add("Neha");
		
		aob1.add("Urmi");
		
		aob1.add("Priti");
		
		aob1.add("Renuka");
		
		aob1.add("Pooja");			
		System.out.println(aob1); 
		
		
		aob1.remove(4);      // for removing index data 		
		System.out.println(aob1);
		
		
		ArrayList<String> aob2 = new ArrayList<String>();
		
		aob2.add("one");
		
		aob2.add("Two");
		
		aob2.add("Three");
		
		aob2.add("Four");
		System.out.println(aob2);
		
		aob1.addAll(aob2);
		System.out.println(aob1);
		
		System.out.println(" Neha is present " +aob1.contains("Neha"));
		
		System.out.println(aob1.containsAll(aob2));
		
		System.out.println(aob1.indexOf("Priti"));
		
		
		//Itrator
		
		Iterator<String> it = aob1.iterator();
		
		  while(it.hasNext()) {
			  
			  System.out.println(it.next());
			  
		  }
		  
		 // using for loop 
		  
		  for(String str: aob1) {
			  
			  System.out.println(str);
			  
		 }
		  
		 // sorting
		  
		  Collections.sort(aob1);
		  
		  System.out.println(" Sorted Elements ");
		  
		  System.out.println(aob1);
		  
		  
		  Collections.shuffle(aob1);
		  
		  System.out.println(" After Suffel " + aob1);
		  
		  
		  Collections.swap(aob1, 2, 4);
		  
		  System.out.println(" After Swap " +aob1);
		
	}

  }
