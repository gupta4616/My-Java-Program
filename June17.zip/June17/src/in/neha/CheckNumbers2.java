// check number 0,+ve,-ve by using if else

package in.neha;
import java.util.Scanner;
public class CheckNumbers2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		 int num;
		 Scanner st = new Scanner(System.in);
		 
		 System.out.println(" Enter any number ");
		 num = st.nextInt();
		 
		 if(num==0) {
			 System.out.println(num+ " is equal to zero ");
		 }
		 
		 else {
		 if(num>0) {
			 System.out.println(num+ " is grater then zero ");
		 }
		 
		 else
			 System.out.println(num+ " is less than zero");
		 }
		
		

	}

}
