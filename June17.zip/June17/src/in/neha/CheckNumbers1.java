// check number is 0,+ve,-ve using if

package in.neha;
import java.util.Scanner;
public class CheckNumbers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 int num;
		 Scanner st = new Scanner(System.in);
		 
		 System.out.println(" Enter any number  ");
		 num = st.nextInt();
		 
		 if(num==0) {
			 System.out.println(num+ " is a zero number ");
		 }
         
		 if(num>0) {
			 System.out.println(num+ " is a positive number ");
			 
		 }
		 
		 if (num<0) {
			 System.out.println(num+ " is a negative number ");
			 
		 }
	}

}
