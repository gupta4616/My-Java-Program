// check number is even or odd

package in.neha;
import java.util.Scanner;
public class CheckNumbersEvenOrOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
	   int num;
	   Scanner St = new Scanner(System.in);
	   
	   System.out.println(" Enter number ");
	   num = St.nextInt();
	   
	   if(num%2==0) {
		   System.out.println(num+ " is an even number ");
	   }
       
	   else {
		   System.out.println(num+ " is an odd number ");
	   }
		   
	}

}
