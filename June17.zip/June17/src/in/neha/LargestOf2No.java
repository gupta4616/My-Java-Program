// largest of 2 number by using if else

package in.neha;

import java.util.Scanner;

public class LargestOf2No {

	public static void main(String[] args) {
		
	    int NO1,NO2;
	    Scanner st = new Scanner(System.in);
	    
	    System.out.println(" Enter a two number, ");
	    NO1 = st.nextInt();
	    NO2 = st.nextInt();
	    
	    if(NO1>NO2) {
		      System.out.println(" largest of " +NO1+ " and " +NO2+ " is "+ NO1);
		    
		    }
		    else {
		    	System.out.println(" largest of " +NO1+ " and " +NO2+ " is "+ NO2);
		    	
		    }
	   
	    
	    
	    
		
		

	}

}
