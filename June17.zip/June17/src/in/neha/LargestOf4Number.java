// largest of 4 number

package in.neha;
import java.util.Scanner;
public class LargestOf4Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 int Num1,Num2,Num3,Num4, large;
		Scanner St = new Scanner(System.in);
		
		System.out.println("Enter any four numbers");
		Num1 = St.nextInt();
		Num2 = St.nextInt();
		Num3 = St.nextInt();
		Num4 = St.nextInt();
		
     large = (Num1 > Num2 && Num1 > Num3 && Num1 > Num4)?Num1:(Num2 > Num1 && Num2 > Num3 && Num2 > Num4)?
		      Num3:Num4;
     System.out.println(" Largest of " +Num1+ " and " +Num2+ " and " +Num3+ " and " +Num4+ " is " +large);
	}

}
