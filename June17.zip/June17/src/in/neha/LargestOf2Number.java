// largest of 2 number by using ternary operator 

package in.neha;

import java.util.Scanner;

public class LargestOf2Number {

	public static void main(String[] args) {
			
		int first, second, large;
        Scanner st = new Scanner(System.in);
        
        System.out.println(" Enter two number ");
        first = st.nextInt();
        second = st.nextInt();
        
      large = (first > second && second > first)?first:second;
    //large = (first > second)?first:second;
      
      System.out.println(" largest of " +first+ " and " +second+ " is " +large);
      
	}
	
}
 