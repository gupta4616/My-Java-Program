// largest of 3 number

package in.neha;

import java.util.Scanner;

public class LargestOf3Number {

	public static void main(String[] args) {

		
		 int num1,num2,num3, large;
		 Scanner st = new Scanner(System.in);
		 
		 System.out.println("Enter three number");
		 num1 = st.nextInt();
		 num2 = st.nextInt();
		 num3 = st.nextInt();
		 
     large = (num1 > num2 && num1 > num3)?num1:(num2 > num1 && num2 > num3)?num2:num3;
     
      System.out.println(" largest of " +num1+ " and " +num2+ " and " +num3+ " is " +large);
      
    
     
	

	}

}
