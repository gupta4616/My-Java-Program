// input data from user

package in.neha;

import java.util.Scanner;

public class UserInputData {
	
	public static void main(String[] args) {
		
         String name;
         
         int age;
         
         float fees;
         
         double amount;
         
         char gen;
         
         Scanner sc = new Scanner(System.in);// Scanner-class 
        
         System.out.println( " Enter Name " );
         name = sc.nextLine();
         
         System.out.println( " Enter Age " );
         age = sc.nextInt();
         
         System.out.println( " Enter Fees " );
         fees = sc.nextFloat();
         
         System.out.println( " Enter Amount " );
         amount = sc.nextDouble();
         
         System.out.println( " Enter Gender m/f " );
         gen = sc.next().charAt(0);
         
         
         System.out.println( " Details are " );
         
         System.out.println( " Name = " + name );
         
         System.out.println( " Age = " + age );
         
         System.out.println( " Fees = " + fees );
         
         System.out.println( " Amount = " + amount );
         
         System.out.println( " Gender = " + gen );
                 
	 }

  }
