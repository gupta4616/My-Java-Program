// check eligible  or not for voting

package in.neha;
import java.util.Scanner;
public class CheckEligibleForVote {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String name;
		 int age;
	     Scanner st = new Scanner(System.in);
	
	     System.out.println(" Enter Name ");
	     name = st.nextLine();
	     
	     System.out.println(" Enter Age ");
	     age = st.nextInt();
	     
	     if(age>=18) {
	        System.out.println( name + " is eligible for voting ");
	     }
	     
	     else {
	    	 System.out.println( name + " is  not eligible for voting ");
	       
	       
	      
	     }
	}

}
