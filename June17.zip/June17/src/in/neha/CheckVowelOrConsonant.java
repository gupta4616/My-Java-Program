// check char as vowel or consonant

package in.neha;
import java.util.Scanner;
public class CheckVowelOrConsonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		char ch;
		Scanner st = new Scanner(System.in);
		 
		System.out.println("Enter char");
		ch = st.next().charAt(0);
		
   if(ch=='a'|| ch=='e'|| ch=='i'|| ch=='o'|| ch=='u') if(ch=='A'|| ch=='E'|| ch=='I'|| ch=='O'|| ch=='U'){
	
		  System.out.println(ch+ " is an vowel " );
   }
			else {
			  System.out.println(ch+ " is an consonant ");
	}
			
	
	}

}
