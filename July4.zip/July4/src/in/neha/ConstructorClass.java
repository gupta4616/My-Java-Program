

package in.neha;

class Constructor {
	
        int id;
        
        String name;
        
       public Constructor(int id, String name) {
    	   
	   //super();
	   
	    this.id = id;
	    
	    this.name = name;
   }

       void display() {
	    System.out.println(" Id = " +id);
	    
	    System.out.println(" Name = " +name);
      }
 
   }

public class ConstructorClass {

	public static void main(String[] args) {
		
		Constructor obj = new Constructor(101, " Neha ");
		
		obj.display();
        

	}

  }
