

package in.neha;

import java.util.Scanner;

class Student {
	
	   int id;
	   
	   float fees;
	   
	   String name;
	   
	  void input() {
		  
		  Scanner sc = new Scanner(System.in);
		  
		  System.out.println(" Enter Student Name ");
		  name = sc.nextLine();
		  
		  System.out.println(" Enter ID Number ");
		  id = sc.nextInt();
		  
		  System.out.println(" Enter Student Fees ");
		  fees = sc.nextFloat();
		  		  
	  }
	  
	  void display() {
		  
		  System.out.println(" Student Name - " +name);
		  
		  System.out.println(" Student ID - " +id);
		  
		  System.out.println(" Student fees - " +fees);
		  
	   }
	   	   
	 }
	

public class ArrayObject {

	public static void main(String[] args) {
		
		Student obj [] = new Student [5];
		
		  for(int i=0; i<obj.length; i++) {
			  
			  obj[i] = new Student();
			  
			  //obj[i].input();
			  
		  }
		  
		  System.out.println();
		  
		  for(int i=0; i<obj.length; i++) {
			  
			  obj[i].input();
			  
		  }
		  
		 System.out.println(" Students Records ");
		 
		  for(int i=0; i<obj.length; i++) {
			  
			  System.out.println();
			  
			  obj[i].display();
			  
	   }	
		  
	 }

  }
