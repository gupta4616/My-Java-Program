

package in.neha;

import java.util.Scanner;

class Employees{
	
	    int eid;
	    
	    String ename;
	    
	    float esalary;
			
		public Employees (int eid, String ename, float esalary) {
			
			//super();
			
			this.eid = eid;
			
			this.ename = ename;
			
			this.esalary = esalary;
			
		}
		
		public Employees() {
			
		}

		void display() {  
	    	
	    	System.out.println(" Employee ID = " +eid );
	    	
	    	System.out.println(" Employee Name = " +ename );
	    	
	    	System.out.println(" Employee salary = " +esalary );
	    	
	    	System.out.println();
	    }
	    
	    void input() {
	    	
	    	Scanner sc = new Scanner(System.in);
	    	
	    	System.out.println(" Enter Employee Name ");
	    	ename = sc.next();
	    	
	    	System.out.println(" Enter Employee Id ");
	    	eid = sc.nextInt();
	    	
	    	System.out.println(" Enter Employee Salary ");
	    	esalary = sc.nextFloat();
	    	
	    }
	    

	    // Setter and Getter method
	    
		public int getEid() {
			return eid;
		}

		public void setEid(int eid) {
			this.eid = eid;
		}

		public String getEname() {
			return ename;
		}

		public void setEname(String ename) {
			this.ename = ename;
		}

		public float getEsalary() {
			return esalary;
		}

		public void setEsalary(float esalary) {
			this.esalary = esalary;
		}
	    	    
    }

public class InitializeInstanceVariable {

	public static void main(String[] args) {
		
		// constructor 
		
		Employees e1 = new Employees(10," Neha ", 50000f);
		
		Employees e2 = new Employees(11," Usha ", 5056.7f);
		
		Employees e3 = new Employees(12," Urmi ", 13000.98f);
		
		e1.display();
		
		e2.display();
		
		e3.display();
		
		// user input 
		
		Employees obj = new Employees();
		
		obj.input();
		
		obj.display();
		
		// setter and getter Method 
		
		Employees sgobj = new Employees();
		
		sgobj.setEid( 101 );
		
		sgobj.setEname("Ravi");
		
		sgobj.setEsalary( 60000f );
		
		System.out.println(sgobj.getEid());
		
		System.out.println(sgobj.getEname());
		
		System.out.println(sgobj.getEsalary());
		
	  }
	
   }
