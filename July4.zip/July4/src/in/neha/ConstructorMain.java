

package in.neha;

class A {
	
	 A() { 
		 
		 super(); // object
		 
		 System.out.println(" Class A Constructor ");
	 }	
	 
   }

class B extends A {

     B() {
    	 
    	 super();  // class A
    	 
    	 System.out.println(" Class B Constructor ");
     }
     
   }

class C extends B {
	
	C() {
		
		super(); // class B
		
		System.out.println(" Class C Constructor ");
	 }
	 
   }


public class ConstructorMain {

	public static void main(String[] args) {
		
		C obj = new C();

	}

 }
