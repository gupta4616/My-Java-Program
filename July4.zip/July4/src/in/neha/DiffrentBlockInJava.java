

package in.neha;

public class DiffrentBlockInJava {
	
	  static {
		   
		   System.out.println(" Static block ");
		   
	    }
	   
	   
	   {
		   
		   System.out.println(" Anonomous block ");
	   }
	   
	   
	   DiffrentBlockInJava() {
		   
		   System.out.println(" Constructor block ");
		   
	   }
	   

	public static void main(String[] args) {
		
		
		System.out.println(" Main Method ");
		
		
		DiffrentBlockInJava obj = new DiffrentBlockInJava();
	
		
	 }

   }
