

package in.neha;

class Employee {
	
	// final int i=100;  // can't be changed 
	 
	 String name = "Neha";
	 
	 static String companyname;
	
	 static {
		 
		 companyname = "TATA";
		 
		 System.out.println(" Static 1 ");
		 
	 }
	 
	 static {
		 
		 System.out.println(" Print Static ");
		 
	 }
	 
	 public static void staticMethod() {
		
		System.out.println(" Employee Static Method ");
		
		System.out.println(" Static = " +companyname);
		
		// System.out.println(" Name = " +name );  // can not accept non static into static
	}
	 
	 public void nonstaticMethod() {
		 
		 System.out.println(" Name = " +name );
		 
		 System.out.println(" Static = " +companyname);
	 }
	
 }

class Accountant {
	
	 public static void staticMethod() {
		 
		 System.out.println(" Accountant static Method ");
	  }
  }

 class FinalAndstatickeywords {

	public static void main(String[] args) {
		
		Accountant obj = new Accountant();
		
		obj.staticMethod();
		
		Employee.staticMethod(); // static method can be called with ref to classname and object
	 	
		Employee ob = new Employee();
		
		ob.nonstaticMethod();
	 }

  }
