

package in.neha;

class Parent {
	
	void display() {
		
		System.out.println(" Parent Display ");
		
	  }
	
   }

class Child {
	
	void C() {
		
		System.out.println(" Child Function Display C ");
			
	 }
	
	void display() {        // function overriding 
		
		System.out.println(" Child Display ");
		
	 }
	
  }

public class FunctionOverriding {

	public static void main(String[] args) {
		
		Child obj1 = new Child();
		
		obj1.C();
		
		obj1.display();
		
		Parent obj = new Parent();
		
		obj.display();
		
		
	  }

   }
