package in.neha;

import java.util.function.Predicate;

public class PredicateMain {

	public static void main(String[] args) {
		
		int[] arr = {8,9,10,11,12,13,14,15,16};
		
		Predicate<Integer>gt,lt;
		
		 gt=(n)->n>10; //grater than
		 
		 lt=(n)->n<15; //less than
		 
		 System.out.println("Numbers<=10and>=15");
		 
		  display(gt.and(lt).negate(),arr);	 
		 
	}

	    static void display(Predicate<Integer>p, int[] arr) {
		
		    for(Integer i:arr) {
		    	
		    	if(p.test(i))
		    		
		    		System.out.println(i+" ");
		    	
		  }
		
	  }

   }
