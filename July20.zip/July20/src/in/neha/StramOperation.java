

package in.neha;

import java.util.Arrays;

import java.util.List;

import java.util.stream.Collectors;

public class StramOperation {

	public static void main(String[] args) {
	
		List<String>lst = Arrays.asList( "USA","Japan","India","China","","Russia","uk" );
		
		
		//String length
		long n = lst.stream().filter(x->x.length()>4).count();
		
		System.out.println(" No of Strings with length more than 4: \n " +n );
		
		
		//String start with "u"
		n=lst.stream().filter(x->x.startsWith("u")).count();
		
		System.out.println(" No of Strings Starting with u: \n" +n );
		
		
		//remove the empty string
		List<String>lst1=lst.stream().filter(x->!x.isEmpty()).collect(Collectors.toList());
		
		System.out.println(" The list after removing the empty string: \n" +lst1);
		
		
		//sorting by uppercase
		List<String>lst2=lst1.stream().sorted().map(X->X.toUpperCase()).collect(Collectors.toList());
		
		System.out.println(" The list after sorting in uppercase: \n" +lst2 );
		
		
		//Array sorted
		String[]arr=lst1.stream().map(X->X.toUpperCase()).toArray(String[]::new);
		
		System.out.println(" Array of sorted strings in uppercase: " );
		
		     for(String i:arr) {
		    	 
		    	 System.out.println(i+",");
		    	 
		  }
		
	   }
 
   }
