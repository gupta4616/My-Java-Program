

package in.neha;

import java.util.function.Predicate;

public class PrediacteDemo {

	public static void main(String[] args) {
		
		Integer[] arr = {8,9,10,11,12,13,14,15,16};
		
		Predicate<Integer>ob = (i)->i<10; //
		
		System.out.println(" Number greater than 10 : ");
		
		myMethod(ob,arr);
		
    }

	 static void myMethod(Predicate<Integer> p, Integer[] arr) {
		 
		  for(Integer i:arr) {
			  
			  if(p.test(i)) System.out.println(i+" ");
		
	}
			
   }

  }
