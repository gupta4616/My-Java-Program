

package in.neha;

interface MyInterface {
	
	 int add(int a, int b);
	 
  }

public class LambdaExpression {

	public static void main(String[] args) {
		
		MyInterface obj = (a,b)->(a+b);
		
		System.out.println("Sum = " +obj.add(4, 8));
		
		
		Runnable r = ()-> {
			
			System.out.println("Run Method");
			
		};
		
		Thread ob = new Thread(r);
		
		ob.start();	

	}

  }
