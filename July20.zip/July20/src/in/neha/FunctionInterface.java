

package in.neha;

import java.util.function.Function;

public class FunctionInterface {

	public static void main(String[] args) {
		
		 Function<String,Integer>len=(str)->str.length();
		 
		 String str = "EDUBRIDGE EDUCATION";
		 
		 System.out.println("Length = "+len.apply(str));
		
	 }

  }
