

package in.neha;

import java.util.function.Predicate;

public class MainPredicate {

	public static void main(String[] args) {
		
		System.out.println(" Predicate Example ");
		
		Predicate<Integer> obj = (i)->(i<10); //
		
		boolean val = obj.test(15);
		
		System.out.println(" return value " +val);

	}

 }
