// Check marks and grade using if else ladder

package in.neha;

import java.util.Scanner;

public class CheckMarksAndGrade {

	public static void main(String[] args) {
	 
	  int marks;
	  char grade;
	  
	  Scanner sc = new Scanner(System.in);
	  
	  System.out.println(" Enter the marks ");
	  marks = sc.nextInt();
	  
	  if(marks>=100 && marks>=0) {
		  System.out.println(" invalid input ");
	  }
	  
	  else if( marks>=80 && marks<=100) {
		  System.out.println(" Grade A ");
	  }
      
	  else if(marks>=60 && marks<=79) {
		  System.out.println(" Grade B ");
	  }
	  
	  else if(marks>=35 && marks<=59) {
		  System.out.println(" Grade c ");
	  }
	  
	  else
		  System.out.println(" fail ");
	  
	  
	}

}
