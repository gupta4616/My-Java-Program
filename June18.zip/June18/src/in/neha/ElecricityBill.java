// Check electricity bill by using if else ladder

package in.neha;

import java.util.Scanner;

public class ElecricityBill {

	public static void main(String[] args) {
	  
		 String Cname;
		 float Bamount;
		 int units;
		 
		 Scanner st = new Scanner(System.in);
		 
		 System.out.println(" Enter consumer name "); 
		 Cname = st.nextLine();
		 
		 System.out.println(" Enter number of units ");
		 units = st.nextInt();
		 
		 // only for checking the condition
		 if(units<=0) {
			 System.out.println(" number of units should not be zero or negative ");
			 System.exit(0);
		 }
		 
		 if(units>=1 && units<=100) {
			 Bamount = units*2.0f;
		 }
		 
		 else if(units>=101 && units<=300) {
			 Bamount = 100*2.0f+(units-100)*3.0f;
		 }
		 
		 else {
			 Bamount = 100*2.0f+(units-200)*3.0f+(units-300)*5.0f;
			 Bamount = Bamount+(Bamount*2.5f)/100;
		 }
		 
		 //System.out.println(" name= " +Cname);
		 
		 //System.out.println(" units= " +units);
		 
		 System.out.println(" Bill amount= " +Bamount);
		 
    }

}
