// Electricity bill count by using class and objects

package in.neha;

public class ElectricityBill2 {

	public static void main(String[] args) {
	

	}

}
