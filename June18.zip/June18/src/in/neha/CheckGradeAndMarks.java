// check grade and marks using if else ladder

package in.neha;

import java.util.Scanner;

public class CheckGradeAndMarks {

	public static void main(String[] args) {
		
		int marks;
		char grade;
		
		Scanner st = new Scanner(System.in);
		
		System.out.println(" Enter Character ");
		grade = st.next().charAt(0);
		
		if(grade == 'A') {
			System.out.println(" Mark Range (80-100)");
		}
		
		else if(grade == 'B') {
			System.out.println(" Mark Range (60-79)");
		}
	    
		else if(grade == 'C') {
			System.out.println(" Mark Range (0-59)");
		}
        
		else
			System.out.println(" Invalid Grade ");
	}

}
