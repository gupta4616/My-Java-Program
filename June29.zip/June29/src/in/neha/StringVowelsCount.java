//

package in.neha;

public class StringVowelsCount {

	public static void main(String[] args) {

		String str = " Welcome to Java ";
		
		int len = str.length();
		
		int VC=0;                  // vowel count 
	
		 for(int i=0; i<len; i++) {
			
			char ch = str.charAt(i); 
			
	if( ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				
	    	VC++;
				
			}
	
		}
		
		 System.out.println(" Number of Vowels = " +VC);
	}
}
