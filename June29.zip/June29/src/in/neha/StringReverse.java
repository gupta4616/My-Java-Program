//

package in.neha;

import java.util.Scanner;

public class StringReverse {

	public static void main(String[] args) {
	
		 String str;
		
		 Scanner sc = new Scanner(System.in);

		 System.out.println(" Enter the string ");
		 str = sc.next();
		 
		   for(int i=str.length()-1; i>=0; i--) {            // NEHA
			                                                 // 0123		   
			 System.out.print(str.charAt(i));
			 
	   } 
		   
	}

}
