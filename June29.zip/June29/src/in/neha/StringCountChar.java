

package in.neha;

public class StringCountChar {

	public static void main(String[] args) {
		
		  String str = "Neha Narayandas Gupta";
		  
		  int word =0;
		  
		     for(int i=0; i<str.length(); i++) {
		    	 
		    	 char ch = str.charAt(i);
		    	 
		    	   if (ch == ' ') {
		    		   
		    		   word++;
		    		   
		       }
		    	   
		   }
		     
		      System.out.println(" Number of Words = " + (word+1) );
		     
		
		
		

	}

}
