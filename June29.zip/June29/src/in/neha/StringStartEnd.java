//

package in.neha;

public class StringStartEnd {

	public static void main(String[] args) {
		
		 String s = "Neha Narayandas Gupta";
		 
		 System.out.println(s.startsWith("Neha") );
		 
		 System.out.println(s.endsWith("Gupta") );

		 
		 //System.out.println(s.startsWith("neha") );
	}

}
