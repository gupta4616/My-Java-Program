//

package in.neha;

public class StringSubstring {

	public static void main(String[] args) {
		
		 String str = "Mahathma Karamchand Gandhi";
		 
		 
		 System.out.print( str.charAt(0) + " . " );
		 
		 System.out.print( str.charAt(str.indexOf( ' ' ) +1) + " . " );
		 
		 
		 int blank = str.lastIndexOf( ' ' )+1;
		 
		 System.out.print( str.charAt(blank) );
		 
          

	}

}
