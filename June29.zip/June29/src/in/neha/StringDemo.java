//

package in.neha;

public class StringDemo {

	public static void main(String[] args) {
		
		 String S1 = " Hello ";
		 
		 String S2 = " Hello ";
		 
		 
		 String S3 = new String (" hello ");
		 
		 String S4 = new String (" hello ");
		 
		     if(S1==S2) {			  
			    System.out.println(" S1 and S2 has same address ");	 //	   
		   }	   
		     else {	   
			    System.out.println(" S1 and S2 has diffrent address ");
		   }
		     
		     
		      if(S1.equals(S2)) {
		    	 System.out.println(" S1 and S2 have same info ");   //
		    	 
		    } 
		      else {
		    	 System.out.println(" S1 and S2 have diffrent info ");
		    }
		     
		     
		        if(S3==S4) {			  
				    System.out.println(" S3 and S4 has same address ");		
			   }	   
			     else {	   
				    System.out.println(" S3 and S4 has diffrent address "); //
			   }
			     
			     
			    if(S3.equals(S4)) {
			    	 System.out.println(" S3 and S4 have same info ");  //
			    	 
			    } 
			     else {
			    	 System.out.println(" S3 and S4 have diffrent info ");
			    }
			    
			      
			    if(S1==S3) {			  
				    System.out.println(" S1 and S3 has same address ");		   
			   }	   
			     else {	   
				    System.out.println(" S1 and S3 has diffrent address "); //
			   }
			     
			     
			     if(S1.equals(S3)) {
			    	 System.out.println(" S1 and S3 have same info ");
			    	 
			    } 
			     else {
			    	 System.out.println(" S1 and S3 have diffrent info "); //
			    }	 
	}

}
