

package in.neha;

public class StringCountWord {

	public static void main(String[] args) {
		
		 String str = "Welcome to Java World";
		         
		 int blank=0;
		 
		 int len = str.length();
		   
		     for(int i=0; i<str.length(); i++) {
		    	 
		    	 char ch = str.charAt(i);
		    	 
		    	    if (ch == ' ') {
		    	 
		    	         blank++;
		    	 
		   }
		     
	   }

	       System.out.println(" Number of character excluding blank = " + (len-blank) );
    }

 }
