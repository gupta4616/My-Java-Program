//

package in.neha;

import java.util.Scanner;

public class StringValidation {

	public static void main(String[] args) {
		
		 String username, password;
		 
		Scanner sc = new Scanner(System.in);
		 
		 System.out.println(" Enter Usename ");
		 username = sc.next();
		 
		 System.out.println(" Enter Password ");
		 password = sc.next();
		 
		     if(username.equals("admin")  &&  password.equals("admin123")){
		     //if(username.equalsIgnoreCase("admin")  &&  password.equalsIgnoreCase("admin123")){   // for ignore the string case 
		    	  System.out.println(" Its Valid ");
		     }
		     
		     else {
		    	 
		    	  System.out.println(" Its not Valid ");
	     }
		     
	}

  }

