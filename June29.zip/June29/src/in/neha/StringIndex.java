//

package in.neha;

public class StringIndex {

	public static void main(String[] args) {
		
		// index -> position ( left to right )
		   
		// last index -> position ( right to left )
		
		
		 String str = "HELLO";
		             //01234
		 
		 System.out.println(" First index of L " +str.indexOf('L') );
		 
		 System.out.println(" Last index of L " +str.lastIndexOf('L'));
		 
		 //System.out.println(" index of H " +str.indexOf('H') );
		 
          //System.out.println(" last index of H " +str.lastIndexOf('H') );
	}

}
