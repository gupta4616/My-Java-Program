//

package in.neha;

public class substring {

	public static void main(String[] args) {
		
        String str = "Neha Narayandas Gupta";
		 
		 int blank1 = str.indexOf(0);
		 System.out.print( str.charAt(0)+ "." );
		 
		 System.out.print( str.charAt(str.indexOf( ' ' ) +1) + "." );
		 
		 
		 int blank2 = str.lastIndexOf( ' ' )+1;
		 
		 System.out.print( str.substring(blank2) );
		 

	}

}
