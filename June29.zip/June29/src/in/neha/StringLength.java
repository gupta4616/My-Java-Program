//

package in.neha;

public class StringLength {

	public static void main(String[] args) {
	  
		 String s = "Hello World";
		
		 int len=s.length();
	  
	  System.out.println(" Number Of Characters = " +len ); 

	}

}
