// find the value of array using linear search 

package pack1;

import java.util.Scanner;

class LinearSearch{
	
	 int array[], size,find;
	  
	void inputData() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter size of an array ");
		size = sc.nextInt();
		array = new int [size];
	 
		System.out.println(" Enter the "+size+" array elements" );
		
		//System.out.println(" Enter array elements ");
		
		  for(int i=0; i<size; i++) {
			  array[i] = sc.nextInt();
		  }
		  
		  System.out.println(" Enter key element to search ");
		  find = sc.nextInt();
	}
	
	 void displayElements() {
		 
		 System.out.println(" Array elements are ");
		 
		  for(int i=0; i<size; i++) {
			  
		 System.out.println(array [i]);
		  }
	 }
	 
	 void linearSearch() {
		 
		 int pos=-1;
		  
		  for(int i=0; i<size; i++) {
			 
			  if(find == array[i]) {
				  
				  pos=i;
				  
				  break;
				  
			  }
		  }
		  
		    if(pos >=0) {
		    	 
		     System.out.println(" Sucessful search ");
		     
		     System.out.println( find + " found at position " + (pos+1));
		     }
		     
		    else {
		    	 
		     System.out.println(" Unsucessful search ");
		     
		    // System.out.println(" Element is not found ");
		     }		 
	   }
  }

public class LinearSearchArray {

public static void main(String[] args) {
	
	LinearSearch obj = new  LinearSearch();
	
	obj.inputData();
	obj.linearSearch();
	obj.displayElements();
	
   }
}
