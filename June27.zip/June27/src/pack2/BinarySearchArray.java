// find array elements using binary search 

package pack2;

import java.util.Scanner;

class BinarySearch {
	
	 int array[], size,find;
	 
	void inputData() {
		
        Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter size of an array ");
		size = sc.nextInt();
		array = new int [size];
	 
		System.out.println(" Enter the "+size+" array elements in ascending order " );//decending 
		
		//System.out.println(" Enter array elements ");
		
		  for(int i=0; i<size; i++) {
			  array[i] = sc.nextInt();
		  }
		  
		  System.out.println(" Enter key element to search ");
		  find = sc.nextInt();
	}
	
	 void SearchBinary() {
		 
		 int l,h, mid=0, pos=-1;
		 
		 l=0;
		 h=size-1;
		 
		  while(l<=h) {
			  mid=(l+h)/2;
			  
			  if(find == array[mid]) {
				  pos=mid;
				  break;				  
			  }
			  
			  else if (find > array [mid]) {
				  l = mid+1;
			  }
			  
			  else if (find < array [mid]) {
				  h = mid-1;
			  }		  
		  }
		 
		      if(pos >=0) {
		    	  
		    	 System.out.println(find + " found at position " +(mid+1));
		      }
		      
		      else {
		    	  
		    	  System.out.println(find+ " not found ");
		      }		
	   }
	
 }
public class BinarySearchArray {

public static void main(String[] args) {
	
	BinarySearch obj = new BinarySearch();
	
	obj.inputData();
	obj.SearchBinary();
	
	
	
		

	}

}
