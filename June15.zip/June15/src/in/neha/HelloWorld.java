// print hello world

package in.neha;

public class HelloWorld {

	public static void main(String[] args) {
		
		
		System.out.println(" Hello world ");

		System.out.println(" Welcome to the java program ");
	 }

  }
