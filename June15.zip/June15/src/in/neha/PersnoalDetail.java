// print personal details

package in.neha;

public class PersnoalDetail {

	public static void main(String[] args) {
		
		   System.out.println( " Neha Narayandas Gupta " );
		   System.out.println( " Barshi-413411, Maharashtra " );
		   System.out.println( " 7385706087 " );
		   
		   
		   System.out.println( 9+8+" Number " );
		   System.out.println( " Number " +9+8 );

	 }

  }
