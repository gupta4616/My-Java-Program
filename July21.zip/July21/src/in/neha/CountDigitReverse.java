

package in.neha;

import java.util.Scanner;

class ReverseClass {
	
	   int no,d,rev=0;
	   
	   ReverseClass(int n) {
		   
		no=n;
		 
	  }
	     
	   void countReverse() {
		   
		   while(no > 0) {
			   
			  d=no%10;
			  
			 //System.out.println(d);
			  
			   rev = rev*10+d;
			   
			   no=no/10;
			   
	    }
		   
		   System.out.println(rev);
		   
	    }
	   
	   void pallandrome() {
		   
		   if(no==rev) {
			   
			   System.out.println(" Number is pallandrome ");
			   
		   }
		   
		   else {
			   
			   System.out.println(" Number is not pallandrome ");
			   
		   }
		      
	   }
		  	   
   }
	   
	   
public class CountDigitReverse {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter the number ");
		int no = sc.nextInt();
		
		ReverseClass ob = new ReverseClass(no);
		
		ob.countReverse();
		
		ob.pallandrome();
			
	 }

  }
