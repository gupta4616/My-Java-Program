

package in.neha;

import java.util.Scanner;

class LargestNumber {
	
	   int num1,num2,large;
	    
	       void input() {
	    	
	    	Scanner sc = new Scanner(System.in);
	    	
	    	System.out.println(" Enter 2 Numbers ");
	    	
	    	num1 = sc.nextInt();
	    	
	    	num2 = sc.nextInt();
	    	
	       }
	       
	       void largeNumber() {
	    	  
	    	  if(num1>num2) {
	    		  
	    		  System.out.println(" largest of " +num1+ " and " +num2+ " is "+ num1);
	  		    
	    		  
	    	}
	    	  
	    	  else {
	    		  
	    		  System.out.println(" largest of " +num1+ " and " +num2+ " is "+ num2);
	  		    
	    		  
	    	}
	   
	   }
	      
	        void ternaryOperator() {
	    	  
	    	  large = (num1>num2 && num2>num1)?num1:num2;
	    	  
	    	  System.out.println(" largest of " +num1+ " and " +num2+ " is "+large);
			     
	       }
     }


public class LargestOf2Numbers {

	public static void main(String[] args) {
		
		LargestNumber ob = new LargestNumber();
		
		ob.input();
		
		ob.largeNumber();
		
		ob.ternaryOperator();	
		
	  }

   }
