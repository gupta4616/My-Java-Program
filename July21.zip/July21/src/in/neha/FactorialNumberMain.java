

package in.neha;

public class FactorialNumberMain {

	public static void main(String[] args) {
		
		FactorialOfGivenNumber ob = new FactorialOfGivenNumber();
		
		ob.input();
		
		ob.factorialNumber();
		
	}

 }
