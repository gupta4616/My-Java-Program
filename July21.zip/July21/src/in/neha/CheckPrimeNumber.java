

package in.neha;

public class CheckPrimeNumber {

	public static void main(String[] args) {
	
		
	}

}
