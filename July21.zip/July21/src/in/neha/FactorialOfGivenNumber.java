

package in.neha;

import java.util.Scanner;

 public class FactorialOfGivenNumber {

		int num;
		double fact=1;
		
		void input() {
			
		System.out.println("Enter the number");
		
		Scanner sc = new Scanner(System.in);
		num=sc.nextInt();
		
		}
		
		void factorialNumber() {
			
		  for(int i=1;i<=num;i++) {
			 
			 fact=fact*i;
	    }
		 
		  System.out.println(fact);

	  }

   }
