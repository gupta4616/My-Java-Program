

package in.neha;

class DigitsOfNumber {
	
	int no;
	
	int count;
	
	DigitsOfNumber(int a) {
		
      no=a;
      
	 }
	
	  void countDigit() {
		 
		 while(no>0) {
			 
			 no=no/10;
			
			 ++count;
			 
	 }
		 
		 System.out.println(" Number Of Digits " +count);
		 
	 }
	  
 }

public class CountDigits {

	public static void main(String[] args) {
		
		DigitsOfNumber ob = new DigitsOfNumber(12821);
		
		ob.countDigit();	

	 }

  }
