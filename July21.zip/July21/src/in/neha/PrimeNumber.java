

package in.neha;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		
	      int n,c=0;
	      
	      Scanner sc = new Scanner(System.in);
	      
	      System.out.println(" Enter the number ");
	      n=sc.nextInt();
	      
	       for(int i=1;i<=n;i=i+2) {
	    	   
	    	   c=0;
	    	   
	    	   for(int j=1;j<=i;j++) {
	    		   
	    		   if(i%j==0) {
	    			   
	    			   c++;
	    			   
	    		   }
	    		   
	    	   }
	    	   
	    	       if(c==2) {
	    	    	   
	    	    	   System.out.println(i+" ");
	    	    	   
	    	    	   
	    	   }
	    	   
	        }
	      
	    }	
			
    }


